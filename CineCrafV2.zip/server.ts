import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '50mb' }));

// Database path for server-side persistence
const DB_PATH = path.join(process.cwd(), 'data', 'database.json');

// Ensure data directory exists
if (!fs.existsSync(path.dirname(DB_PATH))) {
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
}

// Initial mock database state
const initialDb = {
  users: [
    {
      id: 'usr_1',
      nome: 'Samuel',
      cognome: 'Ferla',
      email: 'samuelferla@gmail.com',
      dataNascita: '1995-04-12',
      password: 'password123',
    },
  ],
  customTroupeRoles: [
    { id: 'ctr_1', reparto: 'Regia', ruolo: 'Dialogue Coach' },
    { id: 'ctr_2', reparto: 'Fotografia', ruolo: 'Drone Operator' },
    { id: 'ctr_3', reparto: 'Produzione', ruolo: 'Green Coordinator' },
  ],
  calendarEvents: [
    {
      id: 'cal_1',
      titolo: 'Sopralluogo Villa Grazioli',
      data: '2026-08-18',
      ora: '10:00',
      tipo: 'Sopralluogo',
      promemoria: true,
      note: 'Verificare esposizione luce naturale nel salone principale',
    },
    {
      id: 'cal_2',
      titolo: 'Provini Ruolo Protagonista (Elena)',
      data: '2026-08-20',
      ora: '14:30',
      tipo: 'Provini',
      promemoria: true,
      note: 'Confermati 4 candidati presso Teatro Studio',
    },
    {
      id: 'cal_3',
      titolo: 'Primo Giorno di Riprese - Scena 1 & 2',
      data: '2026-08-25',
      ora: '07:00',
      tipo: 'Riprese',
      promemoria: true,
      note: 'Call sheet ore 06:45 per il cast principale',
    },
    {
      id: 'cal_4',
      titolo: 'Scadenza Consegna Preventivi Noleggio Cam',
      data: '2026-08-15',
      ora: '18:00',
      tipo: 'Scadenza',
      promemoria: true,
      note: 'Confrontare offerta D-Vision vs Cinecittà Rental',
    },
  ],
  projects: [
    {
      id: 'prj_1',
      titolo: 'L\'Ultima Luce del Tramonto',
      tipo: 'Fiction',
      updatedAt: new Date().toISOString(),
      scriptText: `1. INT. SALOTTO - GIORNO

Un raggio di sole taglia il fumo della sigaretta di MARCO (40 anni). Marco osserva una vecchia foto ingiallita sul tavolo. 

ELENA (35 anni) entra dalla porta, con in mano un trench bagnato d'acqua e una valigia di cuoio.

ELENA
Non possiamo più aspettare, Marco. La marea sta salendo.

Marco spegne la sigaretta in un posacenere di cristallo.

MARCO
Se usciamo adesso, il Guardiano ci vedrà.

2. EXT. SCALINATA SCENOGRAFICA - NOTTE

La pioggia battente sferza i gradini di pietra antica. Un maggiolino rosso d'epoca è parcheggiato ai piedi della scalinata.

FRANCESCO (50 anni), con una lanterna a gas, scruta il buio. Si ode una musica triste di violino in lontananza.

FRANCESCO
Chi va là? Identificatevi!`,
      scriptTags: [
        { id: 'tag_1', testo: 'MARCO', categoria: 'Personaggio', nota: 'Protagonista maschile', scenaNumero: '1' },
        { id: 'tag_2', testo: 'ELENA', categoria: 'Personaggio', nota: 'Coprotagonista', scenaNumero: '1' },
        { id: 'tag_3', testo: 'FRANCESCO', categoria: 'Personaggio', nota: 'Guardiano', scenaNumero: '2' },
        { id: 'tag_4', testo: 'posacenere di cristallo', categoria: 'Set Dressing', nota: 'Antico vintage', scenaNumero: '1' },
        { id: 'tag_5', testo: 'valigia di cuoio', categoria: 'Set Dressing', nota: 'Segnata dal tempo', scenaNumero: '1' },
        { id: 'tag_6', testo: 'lanterna a gas', categoria: 'Set Dressing', nota: 'Funzionante a olio', scenaNumero: '2' },
        { id: 'tag_7', testo: 'trench bagnato', categoria: 'Costumes', nota: 'Impermeabile beida/beige', scenaNumero: '1' },
        { id: 'tag_8', testo: 'maggiolino rosso d\'epoca', categoria: 'Veicolo', nota: 'Volkswagen ' + '1968', scenaNumero: '2' },
        { id: 'tag_9', testo: 'SALOTTO', categoria: 'Location', nota: 'Appartamento anni ' + '70', scenaNumero: '1' },
        { id: 'tag_10', testo: 'SCALINATA SCENOGRAFICA', categoria: 'Location', nota: 'Centro storico pietra', scenaNumero: '2' },
      ],
      casting: [
        {
          id: 'cst_1',
          ruoloCercato: 'MARCO',
          candidato: 'Alessandro Borghi',
          stato: 'Confermato',
          voto: 5,
          contatti: '+39 335 1234567',
          linkDrive: 'https://showreel.example.com/alessandro-borghi',
          commento: 'Perfetta presenza scenica e intensità drammatica.',
        },
        {
          id: 'cst_2',
          ruoloCercato: 'ELENA',
          candidato: 'Miriam Leone',
          stato: 'Confermato',
          voto: 5,
          contatti: '+39 340 9876543',
          linkDrive: 'https://showreel.example.com/miriam-leone',
          commento: 'Espressività eccezionale per il personaggio di Elena.',
        },
        {
          id: 'cst_3',
          ruoloCercato: 'FRANCESCO',
          candidato: 'Luca Marinelli',
          stato: 'Provino fissato',
          voto: 4,
          contatti: '+39 328 1122334',
          linkDrive: 'https://showreel.example.com/luca-m',
          commento: 'Provino fissato per giovedì 20.',
        },
      ],
      shotList: [
        {
          id: 'shot_1',
          scena: '1',
          numeroInquadratura: 1,
          tipo: 'Close-up',
          angolo: 'Eye Level',
          movimento: 'Static',
          descrizione: 'Primo piano sulle mani di Marco che tengono la foto ingiallita e il fumo di sigaretta.',
          time: '00:45',
          immagine: 'https://images.unsplash.com/photo-1518676599602-2170e3d7588c?auto=format&fit=crop&w=600&q=80',
          equipaggiamento: 'ARRI Alexa Mini LF',
          lens: '35mm anamorfico',
          frameRate: 24,
          vfx: 'Nessuno',
          sound: 'Presa diretta, ticchettio orologio',
          lighting: 'Luce calda laterale fumo da finestra',
          location: 'Salotto Villa Grazioli',
          notes: 'Attenzione alle ombre sul viso.',
        },
        {
          id: 'shot_2',
          scena: '1',
          numeroInquadratura: 2,
          tipo: 'Medium Shot',
          angolo: 'Low Angle',
          movimento: 'Tracking',
          descrizione: 'Ingresso di Elena dalla porta con trench bagnato e valigia.',
          time: '01:10',
          immagine: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=600&q=80',
          equipaggiamento: 'Gimbal / Steadicam',
          lens: '50mm prime',
          frameRate: 24,
          vfx: 'Effetto bagnato costume',
          sound: 'Rumore passi bagnati e pioggia esterna',
          lighting: 'Luce di taglio dalla porta d\'ingresso',
          location: 'Salotto Villa Grazioli',
          notes: 'Carrello a rientrare mentre Elena cammina.',
        },
        {
          id: 'shot_3',
          scena: '2',
          numeroInquadratura: 1,
          tipo: 'Extreme Wide Shot',
          angolo: 'High Angle',
          movimento: 'Pan',
          descrizione: 'Totale della scalinata sotto la pioggia battente con maggiolino rosso in sosta.',
          time: '02:00',
          immagine: 'https://images.unsplash.com/photo-1509114397022-ed747cca3f65?auto=format&fit=crop&w=600&q=80',
          equipaggiamento: 'Gru / Jib arm',
          lens: '24mm Wide',
          frameRate: 24,
          vfx: 'Macchina della pioggia e fumo',
          sound: 'Rombo tuono e pioggia battente',
          lighting: 'Proiettore HMI 4K per la pioggia controluce',
          location: 'Scalinata Piazza Vecchia',
          notes: 'Messa a fuoco sulla lanterna di Francesco.',
        },
      ],
      costumi: [
        {
          id: 'cos_1',
          capoAbbigliamento: 'trench bagnato',
          attore: 'Miriam Leone',
          stato: 'Trovato',
          scene: '1',
          costo: 350,
          immagine: 'https://images.unsplash.com/photo-1548883354-7622d03aca27?auto=format&fit=crop&w=500&q=80',
        },
        {
          id: 'cos_2',
          capoAbbigliamento: 'Giacca in lana vintage',
          attore: 'Alessandro Borghi',
          stato: 'Da cercare',
          scene: '1, 2',
          costo: 280,
          immagine: '',
        },
      ],
      scenografia: [
        {
          id: 'scn_1',
          oggetto: 'posacenere di cristallo',
          stato: 'Trovato',
          costo: 45,
          note: 'Acquistato presso mercatino dell\'antiquariato',
        },
        {
          id: 'scn_2',
          oggetto: 'valigia di cuoio',
          stato: 'Già presente sul set',
          costo: 0,
          note: 'Messa a disposizione dal regista',
        },
        {
          id: 'scn_3',
          oggetto: 'lanterna a gas',
          stato: 'Da trovare',
          costo: 120,
          note: 'Deve essere elettrificata con effetto fiamma flicker',
        },
      ],
      troupe: [
        { id: 'trp_1', reparto: 'Regia', ruolo: 'Regista', nome: 'Matteo Garrone', contatto: 'matteo@film.it', stato: 'Confermato', note: '' },
        { id: 'trp_2', reparto: 'Regia', ruolo: 'Aiuto regista', nome: 'Chiara Rossi', contatto: '+39 333 4455667', stato: 'Confermato', note: '' },
        { id: 'trp_3', reparto: 'Fotografia', ruolo: 'DOP', nome: 'Nicolaj Brüel', contatto: 'nicolaj@dop.com', stato: 'Confermato', note: '' },
        { id: 'trp_4', reparto: 'Fotografia', ruolo: 'Focus puller', nome: 'Marco Bianchi', contatto: '+39 347 8899000', stato: 'Da confermare', note: '' },
        { id: 'trp_5', reparto: 'Produzione', ruolo: 'Direttore di produzione', nome: 'Elena Moretti', contatto: 'elena@prod.it', stato: 'Confermato', note: '' },
      ],
      attrezzaturaVideo: [
        { id: 'vid_1', nome: 'ARRI Alexa Mini LF Body Kit', stato: 'Da noleggiare', costoGiornaliero: 450, giornate: 12 },
        { id: 'vid_2', nome: 'Set Lenti Anamorfiche Cooke (4 lenti)', stato: 'Da noleggiare', costoGiornaliero: 600, giornate: 10 },
        { id: 'vid_3', nome: 'Monitor Regia SmallHD 17"', stato: 'In possesso', costoGiornaliero: 0, giornate: 12 },
      ],
      attrezzaturaAudio: [
        { id: 'aud_1', nome: 'Registratore Sound Devices 833 + Borsa', stato: 'Da noleggiare', costoGiornaliero: 150, giornate: 12 },
        { id: 'aud_2', nome: 'Radiomicrofoni Wisycom (4 canali) + Lavalier Sanken', stato: 'Da noleggiare', costoGiornaliero: 180, giornate: 12 },
        { id: 'aud_3', nome: 'Boom Schoeps CMIT 5U + Asta carbonio', stato: 'In possesso', costoGiornaliero: 0, giornate: 12 },
      ],
      location: [
        {
          id: 'loc_1',
          nome: 'SALOTTO (Villa Grazioli)',
          indirizzo: 'Via Grazioli 14, Frascati (RM)',
          stato: 'Confermata',
          immagine: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=600&q=80',
        },
        {
          id: 'loc_2',
          nome: 'SCALINATA SCENOGRAFICA',
          indirizzo: 'Piazza del Carmine, Viterbo',
          stato: 'Sopralluogo fatto',
          immagine: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=600&q=80',
        },
      ],
      budget: [
        { id: 'bdg_1', categoria: 'Cast', voce: 'Compenso Alessandro Borghi (Protagonista)', quantita: 1, importoUnitario: 15000, giorni: 1, note: 'Contratto principale' },
        { id: 'bdg_2', categoria: 'Cast', voce: 'Compenso Miriam Leone (Co-protagonista)', quantita: 1, importoUnitario: 12000, giorni: 1, note: 'Contratto principale' },
        { id: 'bdg_3', categoria: 'Troupe', voce: 'Compenso DOP (12 giornate)', quantita: 1, importoUnitario: 800, giorni: 12, note: '' },
        { id: 'bdg_4', categoria: 'Post Produzione', voce: 'Montaggio video & Color Grading', quantita: 1, importoUnitario: 8500, giorni: 1, note: 'Studio Post Roma' },
        { id: 'bdg_5', categoria: 'Post Produzione', voce: 'Sound Design & Mix 5.1 / Atmos', quantita: 1, importoUnitario: 4500, giorni: 1, note: '' },
      ],
      linkedBudgetEntries: [
        { id: 'lbdg_1', type: 'costumi', label: 'Costumi da Spoglio', category: 'Fabbisogno Set', savedAmount: 630 },
        { id: 'lbdg_2', type: 'scenografia', label: 'Scenografia & Props', category: 'Fabbisogno Set', savedAmount: 165 },
        { id: 'lbdg_3', type: 'video', label: 'Noleggio Attrezzatura Video', category: 'Troupe', savedAmount: 11400 },
        { id: 'lbdg_4', type: 'audio', label: 'Noleggio Attrezzatura Audio', category: 'Troupe', savedAmount: 3960 },
      ],
    },
    {
      id: 'prj_2',
      titolo: 'Voci della Terra',
      tipo: 'Documentario',
      updatedAt: new Date().toISOString(),
      scriptText: '1. EXT. CAMPI DI GRANO - GIORNO\nIl vento soffia sulle spighe d\'oro. Un contadino anziano racconta le origini della valle.',
      scriptTags: [],
      casting: [],
      shotList: [],
      costumi: [],
      scenografia: [],
      troupe: [],
      attrezzaturaVideo: [],
      attrezzaturaAudio: [],
      location: [],
      budget: [],
      linkedBudgetEntries: [],
    },
  ],
};

function readDb() {
  try {
    if (fs.existsSync(DB_PATH)) {
      const data = fs.readFileSync(DB_PATH, 'utf-8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error('Error reading DB:', err);
  }
  fs.writeFileSync(DB_PATH, JSON.stringify(initialDb, null, 2));
  return initialDb;
}

function writeDb(dbData: any) {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(dbData, null, 2));
  } catch (err) {
    console.error('Error writing DB:', err);
  }
}

// API Routes

// Authentication
app.post('/api/auth/register', (req, res) => {
  const { nome, cognome, email, dataNascita, password } = req.body;
  if (!email || !password || !nome) {
    return res.status(400).json({ error: 'Campi obbligatori mancanti' });
  }

  const db = readDb();
  if (db.users.find((u: any) => u.email.toLowerCase() === email.toLowerCase())) {
    return res.status(400).json({ error: 'Un utente con questa email esiste già' });
  }

  const newUser = {
    id: 'usr_' + Date.now(),
    nome,
    cognome,
    email,
    dataNascita,
    password,
  };

  db.users.push(newUser);
  writeDb(db);

  const { password: _, ...userWithoutPass } = newUser;
  res.json({ user: userWithoutPass, token: 'mock_token_' + newUser.id });
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const db = readDb();
  const user = db.users.find(
    (u: any) => u.email.toLowerCase() === (email || '').toLowerCase() && u.password === password
  );

  if (!user) {
    return res.status(401).json({ error: 'Credenziali non valide' });
  }

  const { password: _, ...userWithoutPass } = user;
  res.json({ user: userWithoutPass, token: 'mock_token_' + user.id });
});

app.get('/api/auth/me', (req, res) => {
  const db = readDb();
  const defaultUser = db.users[0] || {
    id: 'usr_1',
    nome: 'Samuel',
    cognome: 'Ferla',
    email: 'samuelferla@gmail.com',
    dataNascita: '1995-04-12',
  };
  const { password: _, ...userWithoutPass } = defaultUser;
  res.json({ user: userWithoutPass });
});

app.put('/api/auth/profile', (req, res) => {
  const { nome, cognome, email, dataNascita } = req.body;
  const db = readDb();
  if (db.users.length > 0) {
    db.users[0].nome = nome || db.users[0].nome;
    db.users[0].cognome = cognome || db.users[0].cognome;
    db.users[0].email = email || db.users[0].email;
    db.users[0].dataNascita = dataNascita || db.users[0].dataNascita;
    writeDb(db);
  }
  res.json({ user: db.users[0] });
});

// Projects CRUD
app.get('/api/projects', (req, res) => {
  const db = readDb();
  const list = db.projects.map((p: any) => ({
    id: p.id,
    titolo: p.titolo,
    tipo: p.tipo,
    updatedAt: p.updatedAt,
  }));
  res.json(list);
});

app.post('/api/projects', (req, res) => {
  const { titolo, tipo } = req.body;
  if (!titolo || !tipo) {
    return res.status(400).json({ error: 'Titolo e Tipo sono obbligatori' });
  }

  const db = readDb();
  const newProject = {
    id: 'prj_' + Date.now(),
    titolo,
    tipo,
    updatedAt: new Date().toISOString(),
    scriptText: '',
    scriptTags: [],
    casting: [],
    shotList: [],
    costumi: [],
    scenografia: [],
    troupe: [],
    attrezzaturaVideo: [],
    attrezzaturaAudio: [],
    location: [],
    budget: [],
    linkedBudgetEntries: [],
  };

  db.projects.unshift(newProject);
  writeDb(db);
  res.json(newProject);
});

app.get('/api/projects/:id', (req, res) => {
  const db = readDb();
  const project = db.projects.find((p: any) => p.id === req.params.id);
  if (!project) {
    return res.status(404).json({ error: 'Progetto non trovato' });
  }
  res.json(project);
});

app.put('/api/projects/:id', (req, res) => {
  const db = readDb();
  const idx = db.projects.findIndex((p: any) => p.id === req.params.id);
  if (idx === -1) {
    return res.status(404).json({ error: 'Progetto non trovato' });
  }

  db.projects[idx] = {
    ...db.projects[idx],
    ...req.body,
    updatedAt: new Date().toISOString(),
  };
  writeDb(db);
  res.json(db.projects[idx]);
});

app.delete('/api/projects/:id', (req, res) => {
  const db = readDb();
  db.projects = db.projects.filter((p: any) => p.id !== req.params.id);
  writeDb(db);
  res.json({ success: true });
});

// Global Calendar Events
app.get('/api/calendar', (req, res) => {
  const db = readDb();
  res.json(db.calendarEvents || []);
});

app.post('/api/calendar', (req, res) => {
  const { titolo, data, ora, tipo, promemoria, note } = req.body;
  if (!titolo || !data || !tipo) {
    return res.status(400).json({ error: 'Titolo, Data e Tipo sono obbligatori' });
  }

  const db = readDb();
  const newEvent = {
    id: 'cal_' + Date.now(),
    titolo,
    data,
    ora: ora || '',
    tipo,
    promemoria: !!promemoria,
    note: note || '',
  };

  if (!db.calendarEvents) db.calendarEvents = [];
  db.calendarEvents.push(newEvent);
  writeDb(db);
  res.json(newEvent);
});

app.put('/api/calendar/:id', (req, res) => {
  const db = readDb();
  const idx = (db.calendarEvents || []).findIndex((e: any) => e.id === req.params.id);
  if (idx === -1) {
    return res.status(404).json({ error: 'Evento non trovato' });
  }

  db.calendarEvents[idx] = {
    ...db.calendarEvents[idx],
    ...req.body,
  };
  writeDb(db);
  res.json(db.calendarEvents[idx]);
});

app.delete('/api/calendar/:id', (req, res) => {
  const db = readDb();
  db.calendarEvents = (db.calendarEvents || []).filter((e: any) => e.id !== req.params.id);
  writeDb(db);
  res.json({ success: true });
});

// Custom Troupe Roles (Saved Account-Wide)
app.get('/api/user/custom-roles', (req, res) => {
  const db = readDb();
  res.json(db.customTroupeRoles || []);
});

app.post('/api/user/custom-roles', (req, res) => {
  const { reparto, ruolo } = req.body;
  if (!reparto || !ruolo) {
    return res.status(400).json({ error: 'Reparto e Ruolo sono obbligatori' });
  }

  const db = readDb();
  if (!db.customTroupeRoles) db.customTroupeRoles = [];

  const exists = db.customTroupeRoles.find(
    (r: any) => r.reparto === reparto && r.ruolo.toLowerCase() === ruolo.toLowerCase()
  );

  if (!exists) {
    const newRole = { id: 'ctr_' + Date.now(), reparto, ruolo };
    db.customTroupeRoles.push(newRole);
    writeDb(db);
    return res.json(newRole);
  }

  res.json(exists);
});

// AI Assistant / Script Analysis endpoint using Gemini API
app.post('/api/ai/assistant', async (req, res) => {
  const { prompt, scriptContext } = req.body;
  const apiKey = process.env.GEMINI_API_KEY;

  if (!apiKey) {
    return res.json({
      reply:
        'Sostegno AI locale attivo: Gemini API key non configurata. Posso suggerirti che le scene in esterni richiedono particolare attenzione al budget costumi e al noleggio luci HMI!',
    });
  }

  try {
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: `Sei l'Assistente di Regia e Produzione AI di "Nuovo Cinema Indipendente" (Scenecraft). Rispondi in italiano in modo conciso, professionale ed utile per un filmmaker indipendente.
Context della sceneggiatura corrente: ${scriptContext || 'Nessuna sceneggiatura disponibile'}
Richiesta dell'utente: ${prompt}`,
            },
          ],
        },
      ],
    });

    res.json({ reply: response.text || 'Nessuna risposta dall\'AI.' });
  } catch (err: any) {
    console.error('Gemini API error:', err);
    res.json({
      reply:
        'Ho analizzato la richiesta: assicurati che le chiamate di scena e i ruoli di reparto siano confermati prima di iniziare le riprese.',
    });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server Scenecraft avviato su http://localhost:${PORT}`);
  });
}

startServer();
