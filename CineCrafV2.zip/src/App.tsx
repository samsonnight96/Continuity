import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Navbar } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { WorkspaceView } from './components/WorkspaceView';
import { GlobalCalendarModal } from './components/GlobalCalendarModal';
import { AIAssistantView } from './components/AIAssistantView';
import { ProfileModal } from './components/ProfileModal';
import { NewProjectModal } from './components/NewProjectModal';

import {
  ProjectData,
  CalendarEvent,
  UserProfile,
  CustomRole,
  ProjectType,
  TroupeDepartment,
} from './types';

import {
  fetchProjects,
  fetchProjectDetails,
  createProject,
  updateProject,
  deleteProject,
  fetchCalendarEvents,
  createCalendarEvent,
  updateCalendarEvent,
  deleteCalendarEvent,
  fetchCustomRoles,
  addCustomRole,
} from './lib/api';

export default function App() {
  const [currentView, setCurrentView] = useState<'dashboard' | 'workspace' | 'calendar' | 'ai' | 'profile'>('dashboard');
  const [activeModuleTab, setActiveModuleTab] = useState<string>('spoglio');
  const [searchQuery, setSearchQuery] = useState('');

  // Projects list and active project
  const [projectsList, setProjectsList] = useState<{ id: string; titolo: string; tipo: string }[]>([]);
  const [activeProjectId, setActiveProjectId] = useState<string>('');
  const [activeProject, setActiveProject] = useState<ProjectData | null>(null);

  // Global state
  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>([]);
  const [customRoles, setCustomRoles] = useState<CustomRole[]>([]);
  const [userProfile, setUserProfile] = useState<UserProfile>({
    id: 'usr_1',
    nome: 'Samuel',
    cognome: 'Ferla',
    email: 'samuelferla@gmail.com',
    dataNascita: '1995-04-12',
  });

  const [showNewProjectModal, setShowNewProjectModal] = useState(false);

  // Initial Data Load
  useEffect(() => {
    async function loadInitialData() {
      // Fetch projects list
      const list = await fetchProjects();
      setProjectsList(list);

      if (list.length > 0) {
        const firstId = list[0].id;
        setActiveProjectId(firstId);
        const details = await fetchProjectDetails(firstId);
        setActiveProject(details);
      }

      // Fetch calendar & custom roles
      const cEvents = await fetchCalendarEvents();
      setCalendarEvents(cEvents);

      const cRoles = await fetchCustomRoles();
      setCustomRoles(cRoles);
    }

    loadInitialData();
  }, []);

  // Handle active project change
  const handleSelectProject = async (id: string) => {
    setActiveProjectId(id);
    const details = await fetchProjectDetails(id);
    setActiveProject(details);
  };

  // Handle create new project
  const handleCreateProject = async (titolo: string, tipo: ProjectType) => {
    const newPrj = await createProject(titolo, tipo);
    setProjectsList((prev) => [{ id: newPrj.id, titolo: newPrj.titolo, tipo: newPrj.tipo }, ...prev]);
    setActiveProjectId(newPrj.id);
    setActiveProject(newPrj);
    setCurrentView('workspace');
  };

  // Handle project data update (autosave)
  const handleUpdateProject = async (updatedFields: Partial<ProjectData>) => {
    if (!activeProjectId || !activeProject) return;

    const merged = { ...activeProject, ...updatedFields };
    setActiveProject(merged);

    // Sync title/type to projectsList if updated
    if (updatedFields.titolo || updatedFields.tipo) {
      setProjectsList((prev) =>
        prev.map((p) =>
          p.id === activeProjectId
            ? { ...p, titolo: updatedFields.titolo || p.titolo, tipo: updatedFields.tipo || p.tipo }
            : p
        )
      );
    }

    // Persist to server / local
    await updateProject(activeProjectId, updatedFields);
  };

  // Calendar Event handlers
  const handleAddCalendarEvent = async (evData: Omit<CalendarEvent, 'id'>) => {
    const newEv = await createCalendarEvent(evData);
    setCalendarEvents((prev) => [...prev, newEv]);
  };

  const handleUpdateCalendarEvent = async (id: string, evData: Partial<CalendarEvent>) => {
    const updated = await updateCalendarEvent(id, evData);
    setCalendarEvents((prev) => prev.map((e) => (e.id === id ? { ...e, ...evData } : e)));
  };

  const handleDeleteCalendarEvent = async (id: string) => {
    await deleteCalendarEvent(id);
    setCalendarEvents((prev) => prev.filter((e) => e.id !== id));
  };

  // Custom Roles Handler
  const handleAddCustomRole = async (reparto: TroupeDepartment, ruolo: string) => {
    const newRole = await addCustomRole(reparto, ruolo);
    setCustomRoles((prev) => [...prev, newRole]);
  };

  // Navigate directly to a specific module from Dashboard
  const handleNavigateToModule = (moduleName: string) => {
    setActiveModuleTab(moduleName);
    setCurrentView('workspace');
  };

  // Active reminders for navbar badge
  const todayStr = new Date().toISOString().split('T')[0];
  const activeReminders = calendarEvents.filter((e) => e.promemoria && e.data >= todayStr);

  return (
    <div className="min-h-screen bg-[#F2F0E9] text-[#3D3B30] flex items-center justify-center p-2 sm:p-4 md:p-6 font-sans">
      {/* Outer App Shell Container matching reference screen rounded container with natural tones */}
      <div className="w-full max-w-[1500px] h-[92vh] min-h-[720px] bg-[#F9F8F3] border border-[#CCD5AE] rounded-[32px] shadow-xl flex overflow-hidden">
        {/* Left Vertical Navigation Sidebar */}
        <Sidebar
          currentView={currentView}
          onSelectView={setCurrentView}
          onNewProject={() => setShowNewProjectModal(true)}
          activeProjectTitle={activeProject?.titolo}
          userInitials={`${userProfile.nome.charAt(0)}${userProfile.cognome.charAt(0)}`}
        />

        {/* Right Main Content Panel */}
        <div className="flex-1 flex flex-col min-w-0 bg-[#F2F0E9]">
          {/* Top Bar Header */}
          <Navbar
            currentView={currentView}
            activeProject={activeProject}
            projectsList={projectsList}
            onSelectProject={handleSelectProject}
            onOpenNewProjectModal={() => setShowNewProjectModal(true)}
            unreadRemindersCount={activeReminders.length}
            remindersList={activeReminders}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
          />

          {/* Main Viewport Container */}
          <main className="flex-1 overflow-hidden flex flex-col">
            {currentView === 'dashboard' && (
              <DashboardView
                project={activeProject}
                onNavigateToModule={handleNavigateToModule}
                onOpenNewProjectModal={() => setShowNewProjectModal(true)}
              />
            )}

            {currentView === 'workspace' && (
              <WorkspaceView
                project={activeProject}
                customRoles={customRoles}
                onAddCustomRole={handleAddCustomRole}
                onUpdateProject={handleUpdateProject}
                initialModuleTab={activeModuleTab}
              />
            )}

            {currentView === 'calendar' && (
              <GlobalCalendarModal
                events={calendarEvents}
                onAddEvent={handleAddCalendarEvent}
                onUpdateEvent={handleUpdateCalendarEvent}
                onDeleteEvent={handleDeleteCalendarEvent}
              />
            )}

            {currentView === 'ai' && <AIAssistantView project={activeProject} />}

            {currentView === 'profile' && (
              <ProfileModal
                user={userProfile}
                customRoles={customRoles}
                onUpdateUser={(data) => setUserProfile((prev) => ({ ...prev, ...data }))}
                onAddCustomRole={handleAddCustomRole}
                onClose={() => setCurrentView('dashboard')}
              />
            )}
          </main>
        </div>
      </div>

      {/* Modal for Creating New Project */}
      {showNewProjectModal && (
        <NewProjectModal
          onCreate={handleCreateProject}
          onClose={() => setShowNewProjectModal(false)}
        />
      )}
    </div>
  );
}
