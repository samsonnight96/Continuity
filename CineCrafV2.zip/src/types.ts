export type ProjectType = 'Fiction' | 'Documentario' | 'Docuserie';

export type TagCategory =
  | 'Personaggio'
  | 'Extras'
  | 'Set Dressing'
  | 'Costumes'
  | 'Makeup'
  | 'Stunts'
  | 'Veicolo'
  | 'Special Effects'
  | 'Optical FX'
  | 'Mechanical FX'
  | 'Visual FX'
  | 'Livestock'
  | 'Animal Handler'
  | 'Music'
  | 'Sound'
  | 'Greenery'
  | 'Special Equipment'
  | 'Location'
  | string;

export interface ScriptTag {
  id: string;
  testo: string;
  categoria: TagCategory;
  nota?: string;
  scenaNumero?: string;
}

export type CastingStatus =
  | 'Da contattare'
  | 'Fissare provino'
  | 'Provino fissato'
  | 'Provinato'
  | 'Secondo provino'
  | 'Terzo provino'
  | 'Confermato'
  | 'Scartato';

export interface CastingCandidate {
  id: string;
  ruoloCercato: string;
  candidato: string;
  stato: CastingStatus;
  voto: number; // 1 to 5
  contatti: string;
  linkDrive: string;
  commento: string;
}

export type ShotType =
  | 'Close-up'
  | 'Medium Close-up'
  | 'Extreme Close-up'
  | 'Wide Close-up'
  | 'Medium Shot'
  | 'Close Shot'
  | 'Medium Close Shot'
  | 'Wide Shot'
  | 'Extreme Wide Shot'
  | 'Full Shot'
  | 'Medium Full Shot'
  | 'Long Shot'
  | 'Extreme Long Shot';

export type ShotAngle =
  | 'Camera Height'
  | 'Eye Level'
  | 'Low Angle'
  | 'High Angle'
  | 'Overhead'
  | 'Shoulder Level'
  | 'Hip Level'
  | 'Knee Level'
  | 'Ground Level'
  | 'Dutch Angle'
  | 'Dutch (left)'
  | 'Dutch (right)'
  | 'Framing'
  | 'Single/Two Shot'
  | 'Three Shot'
  | 'Over-the-Shoulder'
  | 'Over-the-Hip'
  | 'Rack Focus'
  | 'Shallow Focus'
  | 'Deep Focus'
  | 'Tilt-Shift'
  | 'Zoom';

export type ShotMovement = 'Static' | 'Pan' | 'Tilt' | 'Swish Pan' | 'Swish Tilt' | 'Tracking';

export interface ShotItem {
  id: string;
  scena: string;
  numeroInquadratura: number;
  tipo: ShotType;
  angolo: ShotAngle;
  movimento: ShotMovement;
  descrizione: string;
  time: string;
  immagine?: string;
  equipaggiamento?: string;
  lens?: string;
  frameRate?: number;
  vfx?: string;
  sound?: string;
  lighting?: string;
  location?: string;
  notes?: string;
}

export type CostumeStatus = 'Da cercare' | 'Da realizzare' | 'Trovato';

export interface CostumeItem {
  id: string;
  capoAbbigliamento: string;
  attore: string;
  stato: CostumeStatus;
  scene: string;
  costo: number;
  immagine?: string;
}

export type PropStatus = 'Da trovare' | 'Trovato' | 'Già presente sul set';

export interface PropItem {
  id: string;
  oggetto: string;
  stato: PropStatus;
  costo: number;
  note: string;
}

export type TroupeDepartment = 'Regia' | 'Fotografia' | 'Produzione';
export type TroupeStatus = 'Da confermare' | 'Confermato';

export interface TroupeMember {
  id: string;
  reparto: TroupeDepartment;
  ruolo: string;
  nome: string;
  contatto: string;
  stato: TroupeStatus;
  note: string;
}

export type EquipmentStatus = 'In possesso' | 'Da noleggiare';

export interface EquipmentItem {
  id: string;
  nome: string;
  stato: EquipmentStatus;
  costoGiornaliero: number;
  giornate: number;
}

export type LocationStatus = 'Da valutare' | 'Sopralluogo fatto' | 'Confermata' | 'Scartata';

export interface LocationItem {
  id: string;
  nome: string;
  indirizzo: string;
  stato: LocationStatus;
  immagine?: string;
}

export type BudgetCategory = 'Cast' | 'Troupe' | 'Fabbisogno Set' | 'Post Produzione';

export interface BudgetItem {
  id: string;
  categoria: BudgetCategory;
  voce: string;
  quantita: number;
  importoUnitario: number;
  giorni: number;
  note: string;
}

export interface LinkedBudgetEntry {
  id: string;
  type: 'costumi' | 'scenografia' | 'video' | 'audio';
  label: string;
  category: BudgetCategory;
  savedAmount: number;
}

export interface ProjectData {
  id: string;
  titolo: string;
  tipo: ProjectType;
  updatedAt: string;
  scriptText: string;
  scriptTags: ScriptTag[];
  casting: CastingCandidate[];
  shotList: ShotItem[];
  costumi: CostumeItem[];
  scenografia: PropItem[];
  troupe: TroupeMember[];
  attrezzaturaVideo: EquipmentItem[];
  attrezzaturaAudio: EquipmentItem[];
  location: LocationItem[];
  budget: BudgetItem[];
  linkedBudgetEntries: LinkedBudgetEntry[];
}

export type CalendarEventType = 'Riprese' | 'Sopralluogo' | 'Provini' | 'Scadenza' | 'Altro';

export interface CalendarEvent {
  id: string;
  titolo: string;
  data: string; // YYYY-MM-DD
  ora?: string;
  tipo: CalendarEventType;
  promemoria: boolean;
  note?: string;
}

export interface UserProfile {
  id: string;
  nome: string;
  cognome: string;
  email: string;
  dataNascita: string;
}

export interface CustomRole {
  id: string;
  reparto: TroupeDepartment;
  ruolo: string;
}
