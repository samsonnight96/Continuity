import React, { useState, useEffect } from 'react';
import {
  ArrowUpRight,
  TrendingUp,
  MapPin,
  Clock,
  Sparkles,
  AlertTriangle,
  Plus,
  Mic,
  Send,
  Clapperboard,
  Film,
  Calendar,
  DollarSign,
  ChevronDown,
} from 'lucide-react';
import { ProjectData } from '../types';
import { askAIAssistant } from '../lib/api';

interface DashboardViewProps {
  project: ProjectData | null;
  onNavigateToModule: (moduleName: string) => void;
  onOpenNewProjectModal: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  project,
  onNavigateToModule,
  onOpenNewProjectModal,
}) => {
  const [aiMessage, setAiMessage] = useState<string>('');
  const [aiInput, setAiInput] = useState<string>('');
  const [aiLoading, setAiLoading] = useState<boolean>(false);
  const [chatHistory, setChatHistory] = useState<{ role: 'user' | 'assistant'; text: string }[]>([]);
  const [clockTime, setClockTime] = useState<string>('12:47:33');

  // Live timer for operational clock matching image 3
  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      setClockTime(now.toTimeString().split(' ')[0]);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Compute live statistics from active project
  const totalShots = project?.shotList.length || 0;
  const completedShots = project?.shotList.filter((s) => s.time).length || 0;
  const shotProgressPercent = totalShots > 0 ? Math.round((completedShots / totalShots) * 100) : 78;

  // Compute budget total
  const manualBudgetSum = (project?.budget || []).reduce(
    (acc, item) => acc + item.quantita * item.importoUnitario * item.giorni,
    0
  );
  const linkedBudgetSum = (project?.linkedBudgetEntries || []).reduce(
    (acc, item) => acc + item.savedAmount,
    0
  );
  const grossBudget = manualBudgetSum + linkedBudgetSum || 156900.67;

  // Handle AI question
  const handleSendAi = async (promptText?: string) => {
    const query = promptText || aiInput;
    if (!query.trim()) return;

    setChatHistory((prev) => [...prev, { role: 'user', text: query }]);
    if (!promptText) setAiInput('');
    setAiLoading(true);

    const scriptContext = `Progetto: ${project?.titolo || 'Nessuno'}. Scene: ${
      project?.scriptTags.length || 0
    } tag spoglio. Inquadrature: ${totalShots}. Budget Totale: €${grossBudget.toLocaleString()}`;

    const response = await askAIAssistant(query, scriptContext);
    setChatHistory((prev) => [...prev, { role: 'assistant', text: response }]);
    setAiLoading(false);
  };

  return (
    <div className="flex-1 p-4 md:p-6 overflow-y-auto space-y-5 text-[#3D3B30] select-none">
      {/* Top Banner Alert matching Natural Tones styling */}
      <div className="bg-white border border-[#E9EDC9] rounded-2xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#E9EDC9] border border-[#CCD5AE] flex items-center justify-center text-[#2D332D] shrink-0">
            <AlertTriangle className="w-5 h-5 text-[#BC6C25]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xs md:text-sm font-bold uppercase tracking-wider text-[#2D332D] font-serif">
                STATO PRODUZIONE & COLLI DI BOTTIGLIA
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#D4A373]/20 text-[#BC6C25] font-semibold">
                Inizio riprese in 2:59:12
              </span>
            </div>
            <p className="text-xs text-[#6B705C] mt-0.5">
              {project
                ? `Progetto "${project.titolo}": ${project.casting.filter((c) => c.stato === 'Confermato').length} attori confermati, ${project.location.length} location ordinate.`
                : 'Seleziona o crea un progetto per monitorare il piano di produzione.'}
            </p>
          </div>
        </div>

        <button
          onClick={() => onNavigateToModule('budget')}
          className="w-10 h-10 rounded-full bg-[#F2F0E9] hover:bg-[#E9EDC9] border border-[#CCD5AE] flex items-center justify-center text-[#2D332D] transition-all shrink-0 shadow-xs"
          title="Apri Budget"
        >
          <ArrowUpRight className="w-5 h-5" />
        </button>
      </div>

      {/* Main Bento Grid matching Natural Tones theme */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* CARD 1: HERO SAND/TERRACOTTA CARD (Top Left - Revenue / Budget Overview) */}
        <div className="lg:col-span-7 bg-[#D4A373] text-[#2D332D] rounded-[28px] p-6 shadow-lg relative overflow-hidden flex flex-col justify-between min-h-[300px]">
          {/* Card Header */}
          <div className="flex items-center justify-between border-b border-[#2D332D]/15 pb-4">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-[#2D332D]/10 flex items-center justify-center">
                <Clapperboard className="w-5 h-5 text-[#2D332D]" />
              </div>
              <h2 className="text-xl md:text-2xl font-bold font-serif uppercase tracking-tight">PREVENTIVO & RIPRESE</h2>
            </div>

            {/* Dropdowns */}
            <div className="flex items-center gap-2 text-xs font-semibold">
              <div className="px-3 py-1.5 rounded-full bg-[#2D332D]/10 border border-[#2D332D]/10 flex items-center gap-1.5 cursor-pointer">
                <span>questa settimana</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </div>
              <div className="px-3 py-1.5 rounded-full bg-[#2D332D]/10 border border-[#2D332D]/10 flex items-center gap-1.5 cursor-pointer">
                <span>EUR, €</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </div>
            </div>
          </div>

          {/* Bar Chart & Hero Metrics Container */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-end my-4">
            {/* Visual Bar Chart */}
            <div className="md:col-span-7 h-40 flex items-end justify-between gap-2 pt-6 relative">
              {/* Active Tooltip Pill */}
              <div className="absolute top-0 left-1/3 bg-[#2D332D] text-[#F2F0E9] text-[11px] font-bold px-3 py-1 rounded-full shadow-md flex items-center gap-1">
                <span>€21,150.88</span>
              </div>

              {/* Day Bars */}
              {[
                { day: 'Lun', height: '60%', active: false },
                { day: 'Mar', height: '85%', active: false },
                { day: 'Mer', height: '45%', active: false },
                { day: 'Gio', height: '100%', active: true },
                { day: 'Ven', height: '70%', active: false },
                { day: 'Sab', height: '55%', active: false },
                { day: 'Dom', height: '40%', active: false },
              ].map((b, i) => (
                <div key={i} className="flex-1 flex flex-col items-center gap-2 h-full justify-end">
                  <div
                    className={`w-full rounded-t-lg transition-all duration-500 ${
                      b.active ? 'bg-[#2D332D] shadow-md' : 'bg-[#2D332D]/20 hover:bg-[#2D332D]/30'
                    }`}
                    style={{ height: b.height }}
                  />
                  <span
                    className={`text-[10px] font-bold uppercase ${
                      b.active ? 'bg-[#2D332D] text-[#F2F0E9] px-2 py-0.5 rounded-full' : 'text-[#2D332D]/70'
                    }`}
                  >
                    {b.day}
                  </span>
                </div>
              ))}
            </div>

            {/* Metrics Column */}
            <div className="md:col-span-5 space-y-4 bg-[#2D332D]/10 p-4 rounded-2xl border border-[#2D332D]/10">
              <div>
                <div className="flex items-center justify-between text-xs font-bold uppercase text-[#2D332D]/80">
                  <span>GROSS BUDGET</span>
                  <span className="bg-[#2D332D] text-[#F2F0E9] text-[10px] font-extrabold px-2 py-0.5 rounded-full">
                    +7,5%
                  </span>
                </div>
                <p className="text-2xl md:text-3xl font-extrabold font-serif mt-1">€{grossBudget.toLocaleString('it-IT')}</p>
              </div>

              <div className="pt-2 border-t border-[#2D332D]/10">
                <div className="flex items-center justify-between text-xs font-bold uppercase text-[#2D332D]/80">
                  <span>COSTO MEDIO SCENA</span>
                  <span className="bg-[#2D332D] text-[#F2F0E9] text-[10px] font-extrabold px-2 py-0.5 rounded-full">
                    +2,4%
                  </span>
                </div>
                <div className="flex items-baseline justify-between mt-1">
                  <p className="text-xl font-bold font-serif">€18.500</p>
                  <span className="text-[10px] text-[#2D332D]/70">Crescita vs ultima sett.</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* CARD 2: FOREST MOSS GREEN CARD (Top Right - Venue Capacity / Avanzamento Scene) */}
        <div className="lg:col-span-5 bg-[#4A5D4E] text-[#F2F0E9] rounded-[28px] p-6 shadow-lg flex flex-col justify-between min-h-[300px]">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-[#F2F0E9]/15 pb-4">
            <h3 className="text-lg font-bold font-serif uppercase tracking-wide">AVANZAMENTO PIANO RIPRESE</h3>
            <div className="px-3 py-1 rounded-full bg-[#F2F0E9]/10 text-xs font-semibold flex items-center gap-1 cursor-pointer">
              <span>questa settimana</span>
              <ChevronDown className="w-3 h-3" />
            </div>
          </div>

          {/* Weekday Percentage Pills */}
          <div className="grid grid-cols-7 gap-1 my-3">
            {[
              { day: 'Mon', val: '78%' },
              { day: 'Tue', val: '82%' },
              { day: 'Wen', val: '91%', highlight: true },
              { day: 'Thu', val: '88%' },
              { day: 'Fri', val: '95%' },
              { day: 'Sat', val: '93%' },
              { day: 'Sun', val: '70%' },
            ].map((item, idx) => (
              <div
                key={idx}
                className={`p-1.5 rounded-full text-center flex flex-col items-center justify-center border transition-all ${
                  item.highlight
                    ? 'bg-[#2D332D] text-[#F2F0E9] border-[#2D332D] font-bold scale-105'
                    : 'bg-[#F2F0E9]/10 border-[#F2F0E9]/10 text-[#F2F0E9]'
                }`}
              >
                <span className="text-[9px] text-[#F2F0E9]/70 uppercase">{item.day}</span>
                <span className="text-[11px] font-black">{item.val}</span>
              </div>
            ))}
          </div>

          {/* Wave line graph preview */}
          <div className="h-20 w-full relative flex items-center justify-center my-2">
            <svg className="w-full h-full overflow-visible" viewBox="0 0 300 60">
              <path
                d="M 0 40 Q 50 10, 100 35 T 200 20 T 300 45"
                fill="none"
                stroke="rgba(242,240,233,0.3)"
                strokeWidth="2"
                strokeDasharray="4 4"
              />
              <path
                d="M 0 30 Q 50 5, 100 25 T 200 15 T 300 30"
                fill="none"
                stroke="#F2F0E9"
                strokeWidth="3"
              />
              <circle cx="100" cy="25" r="5" fill="#F2F0E9" />
            </svg>
          </div>

          {/* Location Badges */}
          <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-[#F2F0E9]/15">
            <span className="text-[10px] font-semibold px-2.5 py-1 rounded-full bg-[#D4A373] text-white flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-white" /> Villa Grazioli
            </span>
            <span className="text-[10px] font-semibold px-2.5 py-1 rounded-full bg-[#E9EDC9] text-[#2D332D] flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#2D332D]" /> Piazza Vecchia
            </span>
            <span className="text-[10px] font-semibold px-2.5 py-1 rounded-full bg-[#CCD5AE] text-[#2D332D] flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#2D332D]" /> Teatro Studio
            </span>
          </div>
        </div>

        {/* CARD 3: SAGE/OLIVE CARD (Bottom Left - Location Map) */}
        <div className="lg:col-span-4 bg-[#CCD5AE] text-[#2D332D] rounded-[28px] p-5 shadow-lg flex flex-col justify-between min-h-[260px] relative overflow-hidden">
          <div className="flex items-center justify-between border-b border-[#2D332D]/15 pb-3">
            <h3 className="text-xl font-bold font-serif uppercase">LOCATION</h3>
            <div className="flex items-center gap-1.5">
              <div className="px-2.5 py-1 rounded-full bg-[#2D332D]/10 text-[11px] font-semibold flex items-center gap-1">
                <span>tutte le scene</span>
                <ChevronDown className="w-3 h-3" />
              </div>
              <button
                onClick={() => onNavigateToModule('location')}
                className="w-8 h-8 rounded-full bg-[#2D332D] text-[#F2F0E9] flex items-center justify-center hover:bg-[#3E473E] transition-all"
              >
                <ArrowUpRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Map Graphic Preview with Pins */}
          <div className="my-2 h-28 w-full bg-[#2D332D]/10 rounded-2xl relative overflow-hidden flex items-center justify-center border border-[#2D332D]/10">
            <div
              className="absolute inset-0 opacity-20"
              style={{
                backgroundImage: `radial-gradient(circle at 10px 10px, #2D332D 1px, transparent 0)`,
                backgroundSize: '20px 20px',
              }}
            />

            {/* Pins */}
            <div className="absolute top-4 left-6 w-3 h-3 bg-[#BC6C25] rounded-full animate-ping" />
            <div className="absolute top-4 left-6 w-3 h-3 bg-[#BC6C25] rounded-full" />

            <div className="absolute bottom-4 right-8 w-3 h-3 bg-[#BC6C25] rounded-full" />

            {/* Active Marker Box */}
            <div className="bg-[#2D332D] text-[#F2F0E9] p-2 rounded-xl text-center shadow-lg border border-[#3E473E] z-10">
              <span className="text-[9px] bg-[#D4A373] text-white px-1.5 py-0.5 rounded-full font-bold">
                +1,1%
              </span>
              <p className="text-xs font-bold mt-1">Salotto Villa Grazioli</p>
              <p className="text-[9px] text-[#A3B18A]">Frascati (RM) - Scena 1</p>
            </div>
          </div>
        </div>

        {/* CARD 4: CREAM SAGE CARD (Bottom Middle - Call Sheet Clock) */}
        <div className="lg:col-span-4 bg-[#E9EDC9] text-[#2D332D] rounded-[28px] p-5 shadow-lg flex flex-col justify-between min-h-[260px]">
          <div className="flex items-center justify-between border-b border-[#2D332D]/15 pb-3">
            <h3 className="text-lg font-bold font-serif uppercase tracking-tight">CALL SHEET TIMING</h3>
            <button
              onClick={() => onNavigateToModule('shotlist')}
              className="w-8 h-8 rounded-full bg-[#2D332D] text-[#F2F0E9] flex items-center justify-center hover:bg-[#3E473E] transition-all"
            >
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>

          {/* Clock Dial Visual */}
          <div className="flex items-center justify-center my-2">
            <div className="w-24 h-24 rounded-full border-4 border-[#2D332D]/20 flex items-center justify-center relative bg-[#2D332D]/5">
              <span className="absolute top-1 text-[9px] font-bold">12</span>
              <span className="absolute right-1 text-[9px] font-bold">3</span>
              <span className="absolute bottom-1 text-[9px] font-bold">6</span>
              <span className="absolute left-1 text-[9px] font-bold">9</span>

              <div className="w-1 h-10 bg-[#BC6C25] rounded-full origin-bottom transform -rotate-45 shadow-md" />
              <div className="w-3 h-3 bg-[#2D332D] rounded-full z-10" />
            </div>
          </div>

          {/* Clock Footer Legend */}
          <div className="flex items-center justify-between text-[10px] font-bold pt-2 border-t border-[#2D332D]/15">
            <div className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-[#BC6C25]" />
              <span>Picco Riprese</span>
            </div>
            <span className="text-[#2D332D]/60">CET / UTC+1</span>
            <span className="bg-[#2D332D] text-[#F2F0E9] px-2 py-0.5 rounded-full font-mono">
              {clockTime}
            </span>
          </div>
        </div>

        {/* CARD 5: DARK FOREST GREEN AI CARD (Bottom Right - AI OPERATIONS LEAD) */}
        <div className="lg:col-span-4 bg-[#2D332D] text-[#F2F0E9] rounded-[28px] p-5 shadow-lg flex flex-col justify-between min-h-[260px] border border-[#3E473E]">
          <div className="flex items-center justify-between border-b border-[#3E473E] pb-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-[#D4A373]/20 text-[#D4A373] flex items-center justify-center">
                <Sparkles className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold font-serif uppercase tracking-wider text-[#F2F0E9]">ASSISTENTE REGIA AI</h3>
            </div>
            <button
              onClick={() => onNavigateToModule('ai')}
              className="w-8 h-8 rounded-full bg-[#3E473E] hover:bg-[#4A5D4E] text-[#F2F0E9] flex items-center justify-center transition-all"
            >
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>

          {/* AI Message Thread */}
          <div className="my-2 space-y-2 max-h-36 overflow-y-auto text-xs">
            {chatHistory.length === 0 ? (
              <div className="flex gap-2 bg-[#3E473E]/50 p-3 rounded-2xl border border-[#3E473E]">
                <img
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80"
                  alt="AI Avatar"
                  className="w-7 h-7 rounded-full object-cover shrink-0 border border-[#D4A373]"
                />
                <div className="space-y-1">
                  <p className="font-semibold text-[#F2F0E9]">
                    Ciao Samuel! <br />
                    {project ? (
                      <>
                        Nel progetto <span className="text-[#D4A373] font-bold">{project.titolo}</span> hai{' '}
                        {project.scriptTags.length} tag nello spoglio e il budget complessivo è ben bilanciato.
                      </>
                    ) : (
                      'Seleziona un progetto per avviare l\'analisi automatica della sceneggiatura.'
                    )}
                  </p>
                </div>
              </div>
            ) : (
              chatHistory.map((item, idx) => (
                <div
                  key={idx}
                  className={`p-2.5 rounded-2xl ${
                    item.role === 'user'
                      ? 'bg-[#D4A373]/20 text-[#D4A373] ml-4 text-right'
                      : 'bg-[#3E473E] text-[#F2F0E9] mr-2'
                  }`}
                >
                  <p className="text-[11px] leading-relaxed">{item.text}</p>
                </div>
              ))
            )}

            {aiLoading && (
              <div className="text-xs text-[#D4A373] animate-pulse flex items-center gap-1.5 p-2">
                <Sparkles className="w-3.5 h-3.5" /> Analisi in corso...
              </div>
            )}
          </div>

          {/* Action Quick Pills */}
          <div className="flex flex-wrap items-center gap-1.5 my-1">
            <button
              onClick={() => handleSendAi('Mostra analisi spese costumi e scenografia')}
              className="text-[10px] font-semibold px-2.5 py-1 rounded-full bg-[#3E473E] hover:bg-[#4A5D4E] text-[#F2F0E9] transition-all flex items-center gap-1 border border-[#CCD5AE]/20"
            >
              🔍 Mostra spese costumi
            </button>
            <button
              onClick={() => handleSendAi('Consiglia suggerimenti casting per ruoli principali')}
              className="text-[10px] font-semibold px-2.5 py-1 rounded-full bg-[#3E473E] hover:bg-[#4A5D4E] text-[#F2F0E9] transition-all flex items-center gap-1 border border-[#CCD5AE]/20"
            >
              🎭 Suggerimenti Casting
            </button>
          </div>

          {/* AI Input Box */}
          <div className="flex items-center gap-2 pt-2 border-t border-[#3E473E]">
            <button
              onClick={() => handleSendAi()}
              className="w-8 h-8 rounded-full bg-[#D4A373] text-white flex items-center justify-center hover:bg-[#BC6C25] transition-all shrink-0 shadow-xs"
            >
              <Plus className="w-4 h-4" />
            </button>
            <input
              type="text"
              placeholder="Chiedi qualcosa all'assistente AI..."
              value={aiInput}
              onChange={(e) => setAiInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendAi()}
              className="bg-transparent text-xs text-[#F2F0E9] placeholder-[#A3B18A] border-none outline-none w-full"
            />
            <button
              onClick={() => handleSendAi()}
              className="text-[#A3B18A] hover:text-[#F2F0E9] transition-colors"
            >
              <Mic className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
