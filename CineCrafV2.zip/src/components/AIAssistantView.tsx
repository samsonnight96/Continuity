import React, { useState } from 'react';
import { Sparkles, Send, Mic, Bot, Film, Clapperboard, DollarSign } from 'lucide-react';
import { ProjectData } from '../types';
import { askAIAssistant } from '../lib/api';

interface AIAssistantViewProps {
  project: ProjectData | null;
}

export const AIAssistantView: React.FC<AIAssistantViewProps> = ({ project }) => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<
    { role: 'user' | 'assistant'; text: string; timestamp: string }[]
  >([
    {
      role: 'assistant',
      text: `Ciao! Sono il tuo Assistente di Regia e Produzione AI per "Nuovo Cinema Indipendente". Posso analizzare la tua sceneggiatura, identificare criticità di budget, suggerire opzioni di casting e verificare i tempi del piano di lavorazione. Come posso aiutarti?`,
      timestamp: 'Adesso',
    },
  ]);

  const handleSend = async (customPrompt?: string) => {
    const textToSend = customPrompt || input;
    if (!textToSend.trim()) return;

    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setMessages((prev) => [...prev, { role: 'user', text: textToSend, timestamp: time }]);
    if (!customPrompt) setInput('');
    setLoading(true);

    const scriptContext = project
      ? `Progetto "${project.titolo}" (${project.tipo}). Tag spoglio: ${project.scriptTags.length}. Shot list: ${project.shotList.length} inquadrature. Cast: ${project.casting.length} candidati. Location: ${project.location.length}.`
      : 'Nessun progetto selezionato.';

    const reply = await askAIAssistant(textToSend, scriptContext);
    setMessages((prev) => [...prev, { role: 'assistant', text: reply, timestamp: time }]);
    setLoading(false);
  };

  return (
    <div className="p-4 md:p-6 text-[#3D3B30] space-y-6 max-w-4xl mx-auto">
      {/* Top Banner */}
      <div className="flex items-center justify-between bg-white p-5 rounded-2xl border border-[#E9EDC9] shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-[#E9EDC9] border border-[#CCD5AE] flex items-center justify-center text-[#BC6C25]">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold font-serif text-[#2D332D]">Assistente AI Scenecraft</h2>
            <p className="text-xs text-[#6B705C]">
              Analisi intelligente di sceneggiatura, casting, logistica e budget.
            </p>
          </div>
        </div>

        {project && (
          <span className="px-3 py-1 rounded-full bg-[#E9EDC9] text-xs font-semibold text-[#2D332D]">
            Progetto attivo: {project.titolo}
          </span>
        )}
      </div>

      {/* Main Chat Box */}
      <div className="bg-white border border-[#E9EDC9] rounded-2xl p-5 shadow-sm flex flex-col h-[500px] justify-between">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-2 text-xs">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[85%] p-3.5 rounded-2xl leading-relaxed ${
                  m.role === 'user'
                    ? 'bg-[#D4A373] text-white rounded-br-none shadow-xs'
                    : 'bg-[#F2F0E9] text-[#3D3B30] border border-[#E9EDC9] rounded-bl-none shadow-xs'
                }`}
              >
                <p className="text-xs">{m.text}</p>
                <span className={`text-[9px] block text-right mt-1 font-mono ${m.role === 'user' ? 'text-white/80' : 'text-[#6B705C]'}`}>
                  {m.timestamp}
                </span>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-2 text-xs text-[#BC6C25] animate-pulse p-2 font-semibold">
              <Bot className="w-4 h-4" /> Elaborazione risposta AI...
            </div>
          )}
        </div>

        {/* Action Pills */}
        <div className="flex flex-wrap items-center gap-2 py-3 border-t border-[#E9EDC9]">
          <button
            onClick={() => handleSend('Analizza la sceneggiatura ed estrai i personaggi principali')}
            className="text-[11px] font-semibold px-3 py-1.5 rounded-full bg-[#F2F0E9] hover:bg-[#E5E2D8] text-[#3D3B30] transition-all border border-[#CCD5AE]"
          >
            📜 Analizza Sceneggiatura
          </button>
          <button
            onClick={() => handleSend('Controlla la coerenza del budget e avvisami delle spese piu alte')}
            className="text-[11px] font-semibold px-3 py-1.5 rounded-full bg-[#F2F0E9] hover:bg-[#E5E2D8] text-[#3D3B30] transition-all border border-[#CCD5AE]"
          >
            💰 Verifica Budget
          </button>
          <button
            onClick={() => handleSend('Dammi consigli per organizzare il piano di riprese delle location')}
            className="text-[11px] font-semibold px-3 py-1.5 rounded-full bg-[#F2F0E9] hover:bg-[#E5E2D8] text-[#3D3B30] transition-all border border-[#CCD5AE]"
          >
            🎬 Consigli Piano Riprese
          </button>
        </div>

        {/* Input Bar */}
        <div className="flex items-center gap-2 bg-[#F2F0E9] p-2 rounded-2xl border border-[#CCD5AE]">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Scrivi un messaggio per l'assistente AI..."
            className="bg-transparent text-xs text-[#3D3B30] placeholder-[#A3B18A] outline-none w-full px-3"
          />
          <button
            onClick={() => handleSend()}
            className="p-2.5 rounded-xl bg-[#D4A373] hover:bg-[#BC6C25] text-white transition-all shadow-xs"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
