import React from 'react';
import {
  LayoutDashboard,
  FolderKanban,
  Calendar,
  Bot,
  User,
  Plus,
  Clapperboard,
  DollarSign,
  Film,
  Settings,
} from 'lucide-react';

interface SidebarProps {
  currentView: 'dashboard' | 'workspace' | 'calendar' | 'ai' | 'profile';
  onSelectView: (view: 'dashboard' | 'workspace' | 'calendar' | 'ai' | 'profile') => void;
  onNewProject: () => void;
  activeProjectTitle?: string;
  userInitials?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onSelectView,
  onNewProject,
  activeProjectTitle,
  userInitials = 'SF',
}) => {
  return (
    <div className="w-16 md:w-20 bg-[#2D332D] text-[#F2F0E9] flex flex-col items-center justify-between py-5 border-r border-[#3E473E] rounded-l-[28px] shrink-0 select-none">
      {/* Top Branding / Logo */}
      <div className="flex flex-col items-center gap-6">
        <button
          onClick={() => onSelectView('profile')}
          className="w-11 h-11 rounded-full bg-[#3E473E] flex items-center justify-center text-[#F2F0E9] font-semibold text-sm hover:bg-[#4A5D4E] transition-all shadow-md border border-[#CCD5AE]/20"
          title="Profilo Utente"
        >
          {userInitials}
        </button>

        {/* Navigation Items matching screen 3 */}
        <nav className="flex flex-col gap-3">
          <button
            onClick={() => onSelectView('dashboard')}
            className={`w-11 h-11 rounded-2xl flex items-center justify-center transition-all ${
              currentView === 'dashboard'
                ? 'bg-[#D4A373] text-white shadow-lg scale-105'
                : 'text-[#A3B18A] hover:text-[#F2F0E9] hover:bg-[#3E473E]/60'
            }`}
            title="Dashboard Overview"
          >
            <LayoutDashboard className="w-5 h-5" />
          </button>

          <button
            onClick={() => onSelectView('workspace')}
            className={`w-11 h-11 rounded-2xl flex items-center justify-center transition-all ${
              currentView === 'workspace'
                ? 'bg-[#D4A373] text-white shadow-lg scale-105'
                : 'text-[#A3B18A] hover:text-[#F2F0E9] hover:bg-[#3E473E]/60'
            }`}
            title="Workspace Progetto"
          >
            <Film className="w-5 h-5" />
          </button>

          <button
            onClick={() => onSelectView('calendar')}
            className={`w-11 h-11 rounded-2xl flex items-center justify-center transition-all ${
              currentView === 'calendar'
                ? 'bg-[#D4A373] text-white shadow-lg scale-105'
                : 'text-[#A3B18A] hover:text-[#F2F0E9] hover:bg-[#3E473E]/60'
            }`}
            title="Calendario Globale"
          >
            <Calendar className="w-5 h-5" />
          </button>

          <button
            onClick={() => onSelectView('ai')}
            className={`w-11 h-11 rounded-2xl flex items-center justify-center transition-all ${
              currentView === 'ai'
                ? 'bg-[#D4A373] text-white shadow-lg scale-105'
                : 'text-[#A3B18A] hover:text-[#F2F0E9] hover:bg-[#3E473E]/60'
            }`}
            title="Assistente AI Scenecraft"
          >
            <Bot className="w-5 h-5" />
          </button>

          <button
            onClick={() => onSelectView('profile')}
            className={`w-11 h-11 rounded-2xl flex items-center justify-center transition-all ${
              currentView === 'profile'
                ? 'bg-[#D4A373] text-white shadow-lg scale-105'
                : 'text-[#A3B18A] hover:text-[#F2F0E9] hover:bg-[#3E473E]/60'
            }`}
            title="Impostazioni Profilo"
          >
            <Settings className="w-5 h-5" />
          </button>
        </nav>
      </div>

      {/* Bottom Actions */}
      <div className="flex flex-col items-center gap-4">
        {/* + Add New Project Button */}
        <button
          onClick={onNewProject}
          className="w-11 h-14 bg-[#D4A373] text-white rounded-full flex flex-col items-center justify-center hover:bg-[#BC6C25] transition-all shadow-md group"
          title="Nuovo Progetto"
        >
          <Plus className="w-6 h-6 group-hover:scale-110 transition-transform" />
        </button>

        {/* User Avatar */}
        <button
          onClick={() => onSelectView('profile')}
          className="w-10 h-10 rounded-full overflow-hidden border-2 border-[#D4A373] hover:opacity-80 transition-opacity"
        >
          <img
            src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80"
            alt="User Avatar"
            className="w-full h-full object-cover"
          />
        </button>
      </div>
    </div>
  );
};
