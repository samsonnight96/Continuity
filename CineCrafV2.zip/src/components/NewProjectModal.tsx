import React, { useState } from 'react';
import { Film, Sparkles, X } from 'lucide-react';
import { ProjectType } from '../types';

interface NewProjectModalProps {
  onCreate: (titolo: string, tipo: ProjectType) => void;
  onClose: () => void;
}

export const NewProjectModal: React.FC<NewProjectModalProps> = ({ onCreate, onClose }) => {
  const [titolo, setTitolo] = useState('');
  const [tipo, setTipo] = useState<ProjectType>('Fiction');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!titolo.trim()) return;
    onCreate(titolo.trim(), tipo);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="bg-white border border-[#E9EDC9] rounded-2xl w-full max-w-md p-6 space-y-5 shadow-2xl animate-in fade-in text-[#3D3B30]">
        <div className="flex items-center justify-between border-b border-[#E9EDC9] pb-3">
          <h3 className="text-base font-bold font-serif flex items-center gap-2 text-[#2D332D]">
            <Sparkles className="w-5 h-5 text-[#BC6C25]" /> Nuovo Progetto Cinematografico
          </h3>
          <button onClick={onClose} className="text-[#6B705C] hover:text-[#3D3B30]">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="text-[#5A584D] block mb-1 font-semibold">Titolo Progetto *</label>
            <input
              type="text"
              required
              value={titolo}
              onChange={(e) => setTitolo(e.target.value)}
              placeholder="es. L'Ultima Luce del Tramonto"
              className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-3 text-sm text-[#3D3B30] placeholder-[#A3B18A] outline-none focus:border-[#D4A373]"
            />
          </div>

          <div>
            <label className="text-[#5A584D] block mb-1 font-semibold">Tipo Produzione *</label>
            <select
              value={tipo}
              onChange={(e) => setTipo(e.target.value as ProjectType)}
              className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-3 text-sm text-[#3D3B30] outline-none focus:border-[#D4A373]"
            >
              <option value="Fiction">Fiction</option>
              <option value="Documentario">Documentario</option>
              <option value="Docuserie">Docuserie</option>
            </select>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#E9EDC9]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 bg-[#E5E2D8] hover:bg-[#CCD5AE] text-[#3D3B30] rounded-xl text-xs font-semibold"
            >
              Annulla
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-[#D4A373] hover:bg-[#BC6C25] text-white rounded-xl text-xs font-bold shadow-xs"
            >
              Crea Workspace Progetto
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
