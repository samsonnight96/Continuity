import React, { useState, useEffect } from 'react';
import {
  Calendar as CalendarIcon,
  Plus,
  ChevronLeft,
  ChevronRight,
  Bell,
  Clock,
  AlertCircle,
  X,
  Edit3,
} from 'lucide-react';
import { CalendarEvent, CalendarEventType } from '../types';
import { DeleteConfirmButton } from './common/DeleteConfirmButton';

interface GlobalCalendarProps {
  events: CalendarEvent[];
  onAddEvent: (ev: Omit<CalendarEvent, 'id'>) => void;
  onUpdateEvent: (id: string, ev: Partial<CalendarEvent>) => void;
  onDeleteEvent: (id: string) => void;
}

const EVENT_TYPES: CalendarEventType[] = ['Riprese', 'Sopralluogo', 'Provini', 'Scadenza', 'Altro'];

const TYPE_COLORS: Record<CalendarEventType, string> = {
  Riprese: 'bg-[#BC6C25] text-white border-[#BC6C25]',
  Sopralluogo: 'bg-[#CCD5AE] text-[#2D332D] border-[#CCD5AE]',
  Provini: 'bg-[#D4A373] text-white border-[#D4A373]',
  Scadenza: 'bg-[#4A5D4E] text-white border-[#4A5D4E]',
  Altro: 'bg-[#E5E2D8] text-[#3D3B30] border-[#CCD5AE]',
};

export const GlobalCalendarModal: React.FC<GlobalCalendarProps> = ({
  events,
  onAddEvent,
  onUpdateEvent,
  onDeleteEvent,
}) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form
  const [titolo, setTitolo] = useState('');
  const [data, setData] = useState('');
  const [ora, setOra] = useState('');
  const [tipo, setTipo] = useState<CalendarEventType>('Riprese');
  const [promemoria, setPromemoria] = useState(true);
  const [note, setNote] = useState('');

  // Notification Permission State
  const [notifPermission, setNotifPermission] = useState<NotificationPermission>(
    typeof window !== 'undefined' && 'Notification' in window ? Notification.permission : 'default'
  );

  const requestNotificationPermission = async () => {
    if ('Notification' in window) {
      const perm = await Notification.requestPermission();
      setNotifPermission(perm);
    }
  };

  const handleOpenAdd = (defaultDate = '') => {
    setEditingId(null);
    setTitolo('');
    setData(defaultDate || new Date().toISOString().split('T')[0]);
    setOra('09:00');
    setTipo('Riprese');
    setPromemoria(true);
    setNote('');
    setShowModal(true);
  };

  const handleOpenEdit = (ev: CalendarEvent) => {
    setEditingId(ev.id);
    setTitolo(ev.titolo);
    setData(ev.data);
    setOra(ev.ora || '');
    setTipo(ev.tipo);
    setPromemoria(ev.promemoria);
    setNote(ev.note || '');
    setShowModal(true);
  };

  const handleSave = () => {
    if (!titolo || !data) return;

    if (editingId) {
      onUpdateEvent(editingId, { titolo, data, ora, tipo, promemoria, note });
    } else {
      onAddEvent({ titolo, data, ora, tipo, promemoria, note });
    }
    setShowModal(false);
  };

  // Calendar Days Calculation
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const firstDayOfMonth = new Date(year, month, 1);
  const lastDayOfMonth = new Date(year, month + 1, 0);

  const daysInMonth = lastDayOfMonth.getDate();
  const startDayOfWeek = (firstDayOfMonth.getDay() + 6) % 7; // Monday start

  const monthNames = [
    'Gennaio',
    'Febbraio',
    'Marzo',
    'Aprile',
    'Maggio',
    'Giugno',
    'Luglio',
    'Agosto',
    'Settembre',
    'Ottobre',
    'Novembre',
    'Dicembre',
  ];

  // Upcoming reminders
  const todayStr = new Date().toISOString().split('T')[0];
  const upcomingReminders = events
    .filter((e) => e.promemoria && e.data >= todayStr)
    .sort((a, b) => a.data.localeCompare(b.data))
    .slice(0, 8);

  const expiredReminders = events
    .filter((e) => e.promemoria && e.data < todayStr)
    .sort((a, b) => b.data.localeCompare(a.data));

  return (
    <div className="p-4 md:p-6 text-[#3D3B30] space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-[#E9EDC9] shadow-sm">
        <div>
          <h2 className="text-lg font-bold font-serif flex items-center gap-2 text-[#2D332D]">
            <CalendarIcon className="w-5 h-5 text-[#BC6C25]" /> Calendario Globale Produzioni
          </h2>
          <p className="text-xs text-[#6B705C] mt-1">
            Condiviso trasversalmente tra tutti i tuoi progetti cinematografici.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {notifPermission !== 'granted' && (
            <button
              onClick={requestNotificationPermission}
              className="px-3.5 py-2 bg-[#F2F0E9] hover:bg-[#E5E2D8] text-[#3D3B30] text-xs font-semibold rounded-xl transition-all flex items-center gap-1.5 border border-[#CCD5AE]"
            >
              <Bell className="w-4 h-4 text-[#BC6C25]" />
              <span>Attiva Notifiche Browser</span>
            </button>
          )}

          <button
            onClick={() => handleOpenAdd()}
            className="px-4 py-2.5 bg-[#D4A373] hover:bg-[#BC6C25] text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" /> Nuovo Evento
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Main Monthly Calendar Grid */}
        <div className="lg:col-span-8 bg-white p-5 rounded-2xl border border-[#E9EDC9] shadow-sm space-y-4">
          {/* Calendar Month Header */}
          <div className="flex items-center justify-between border-b border-[#E9EDC9] pb-4">
            <h3 className="text-base font-bold font-serif text-[#2D332D] uppercase tracking-wider flex items-center gap-2">
              {monthNames[month]} {year}
            </h3>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentDate(new Date(year, month - 1, 1))}
                className="p-2 rounded-xl bg-[#F2F0E9] hover:bg-[#E5E2D8] text-[#3D3B30] transition-all"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => setCurrentDate(new Date())}
                className="px-3 py-1.5 rounded-xl bg-[#F2F0E9] text-xs font-semibold hover:bg-[#E5E2D8] text-[#3D3B30]"
              >
                Oggi
              </button>
              <button
                onClick={() => setCurrentDate(new Date(year, month + 1, 1))}
                className="p-2 rounded-xl bg-[#F2F0E9] hover:bg-[#E5E2D8] text-[#3D3B30] transition-all"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Weekday Labels */}
          <div className="grid grid-cols-7 gap-2 text-center text-xs font-bold text-[#6B705C] uppercase">
            {['Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab', 'Dom'].map((d) => (
              <div key={d} className="py-1">
                {d}
              </div>
            ))}
          </div>

          {/* Month Days Grid */}
          <div className="grid grid-cols-7 gap-2">
            {/* Empty Offset Days */}
            {Array.from({ length: startDayOfWeek }).map((_, i) => (
              <div key={'empty-' + i} className="h-24 bg-[#F2F0E9] opacity-30 rounded-xl" />
            ))}

            {/* Days of Month */}
            {Array.from({ length: daysInMonth }).map((_, dayIdx) => {
              const dayNum = dayIdx + 1;
              const dateFormatted = `${year}-${String(month + 1).padStart(2, '0')}-${String(
                dayNum
              ).padStart(2, '0')}`;
              const isToday = dateFormatted === todayStr;

              const dayEvents = events.filter((e) => e.data === dateFormatted);

              return (
                <div
                  key={dayNum}
                  onClick={() => handleOpenAdd(dateFormatted)}
                  className={`h-24 p-2 rounded-xl border transition-all cursor-pointer flex flex-col justify-between overflow-hidden group ${
                    isToday
                      ? 'bg-[#E9EDC9] border-[#D4A373]'
                      : 'bg-[#F9F8F3] border-[#E9EDC9] hover:border-[#CCD5AE]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-xs font-bold ${
                        isToday
                          ? 'bg-[#D4A373] text-white w-5 h-5 rounded-full flex items-center justify-center'
                          : 'text-[#3D3B30]'
                      }`}
                    >
                      {dayNum}
                    </span>
                  </div>

                  <div className="space-y-1 overflow-y-auto max-h-14">
                    {dayEvents.map((ev) => (
                      <div
                        key={ev.id}
                        onClick={(e) => {
                          e.stopPropagation();
                          handleOpenEdit(ev);
                        }}
                        className={`text-[9px] font-bold px-1.5 py-0.5 rounded truncate border ${
                          TYPE_COLORS[ev.tipo] || 'bg-[#CCD5AE] text-[#2D332D] border-[#CCD5AE]'
                        }`}
                      >
                        {ev.ora ? `${ev.ora} ` : ''}
                        {ev.titolo}
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Side Panels: Upcoming Reminders & Expired Reminders */}
        <div className="lg:col-span-4 space-y-6">
          {/* Upcoming Reminders Card */}
          <div className="bg-white p-5 rounded-2xl border border-[#E9EDC9] shadow-sm space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#6B705C] flex items-center gap-2 font-serif">
              <Bell className="w-4 h-4 text-[#BC6C25]" /> Prossimi Promemoria ({upcomingReminders.length})
            </h3>

            <div className="space-y-2.5 max-h-64 overflow-y-auto">
              {upcomingReminders.length === 0 ? (
                <p className="text-xs text-[#6B705C] py-4 text-center">Nessun promemoria futuro programmato.</p>
              ) : (
                upcomingReminders.map((ev) => (
                  <div
                    key={ev.id}
                    onClick={() => handleOpenEdit(ev)}
                    className="p-3 bg-[#F9F8F3] hover:bg-[#F2F0E9] rounded-xl border border-[#E9EDC9] text-xs space-y-1 cursor-pointer transition-all"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-[#3D3B30]">{ev.titolo}</span>
                      <span
                        className={`text-[9px] px-2 py-0.5 rounded-full font-bold ${
                          TYPE_COLORS[ev.tipo]
                        }`}
                      >
                        {ev.tipo}
                      </span>
                    </div>
                    <div className="text-[10px] text-[#6B705C] flex items-center gap-2">
                      <span>📅 {ev.data}</span>
                      {ev.ora && <span>⏰ {ev.ora}</span>}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Expired Reminders Card */}
          {expiredReminders.length > 0 && (
            <div className="bg-white p-5 rounded-2xl border border-[#E9EDC9] shadow-sm space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#BC6C25] flex items-center gap-2 font-serif">
                <AlertCircle className="w-4 h-4" /> Promemoria Scaduti ({expiredReminders.length})
              </h3>

              <div className="space-y-2 max-h-48 overflow-y-auto">
                {expiredReminders.map((ev) => (
                  <div
                    key={ev.id}
                    onClick={() => handleOpenEdit(ev)}
                    className="p-3 bg-[#D4A373]/15 hover:bg-[#D4A373]/25 rounded-xl border border-[#D4A373]/30 text-xs space-y-1 cursor-pointer transition-all"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-[#3D3B30]">{ev.titolo}</span>
                      <span className="text-[9px] text-[#BC6C25] font-semibold">{ev.data}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Event Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-[#E9EDC9] rounded-2xl w-full max-w-lg p-6 space-y-4 shadow-2xl animate-in fade-in text-[#3D3B30]">
            <div className="flex items-center justify-between border-b border-[#E9EDC9] pb-3">
              <h3 className="text-base font-bold font-serif text-[#2D332D]">
                {editingId ? 'Modifica Evento' : 'Nuovo Evento Calendario'}
              </h3>
              {editingId && <DeleteConfirmButton onConfirm={() => { onDeleteEvent(editingId); setShowModal(false); }} />}
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-[#6B705C] block mb-1">Titolo Evento *</label>
                <input
                  type="text"
                  value={titolo}
                  onChange={(e) => setTitolo(e.target.value)}
                  placeholder="es. Sopralluogo Villa Grazioli"
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[#6B705C] block mb-1">Data *</label>
                  <input
                    type="date"
                    value={data}
                    onChange={(e) => setData(e.target.value)}
                    className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                  />
                </div>

                <div>
                  <label className="text-[#6B705C] block mb-1">Ora (opzionale)</label>
                  <input
                    type="time"
                    value={ora}
                    onChange={(e) => setOra(e.target.value)}
                    className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                  />
                </div>
              </div>

              <div>
                <label className="text-[#6B705C] block mb-1">Tipo Evento *</label>
                <select
                  value={tipo}
                  onChange={(e) => setTipo(e.target.value as CalendarEventType)}
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                >
                  {EVENT_TYPES.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              </div>

              <label className="flex items-center gap-2 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={promemoria}
                  onChange={(e) => setPromemoria(e.target.checked)}
                  className="w-4 h-4 rounded text-[#D4A373] accent-[#D4A373]"
                />
                <span className="text-[#3D3B30]">Attiva promemoria per questo evento</span>
              </label>

              <div>
                <label className="text-[#6B705C] block mb-1">Note (opzionale)</label>
                <textarea
                  rows={2}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Dettagli e contatti..."
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#E9EDC9]">
              <button onClick={() => setShowModal(false)} className="px-4 py-2 bg-[#E5E2D8] text-[#3D3B30] rounded-xl text-xs font-semibold hover:bg-[#CCD5AE]">
                Annulla
              </button>
              <button onClick={handleSave} className="px-4 py-2 bg-[#D4A373] hover:bg-[#BC6C25] text-white rounded-xl text-xs font-bold">
                Salva Evento
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
