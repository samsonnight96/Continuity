import React, { useState, useRef, useEffect } from 'react';
import {
  FileText,
  UserCheck,
  Users,
  Camera,
  Shirt,
  Package,
  Video,
  Mic,
  MapPin,
  DollarSign,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { ProjectData, CustomRole, TroupeDepartment } from '../types';
import { ScriptBreakdownModule } from './modules/ScriptBreakdownModule';
import { CastingModule } from './modules/CastingModule';
import { CastModule } from './modules/CastModule';
import { ShotListModule } from './modules/ShotListModule';
import { CostumesModule } from './modules/CostumesModule';
import { PropsModule } from './modules/PropsModule';
import { TroupeModule } from './modules/TroupeModule';
import { EquipmentModule } from './modules/EquipmentModule';
import { LocationModule } from './modules/LocationModule';
import { BudgetModule } from './modules/BudgetModule';

interface WorkspaceViewProps {
  project: ProjectData | null;
  customRoles: CustomRole[];
  onAddCustomRole: (reparto: TroupeDepartment, ruolo: string) => void;
  onUpdateProject: (updated: Partial<ProjectData>) => void;
  initialModuleTab?: string;
}

const MODULE_TABS = [
  { id: 'spoglio', label: '1. Spoglio', icon: FileText },
  { id: 'casting', label: '2. Casting', icon: UserCheck },
  { id: 'cast', label: '3. Cast', icon: Users },
  { id: 'shotlist', label: '4. Shot List', icon: Camera },
  { id: 'costumi', label: '5. Costumi', icon: Shirt },
  { id: 'props', label: '6. Scenografia', icon: Package },
  { id: 'troupe', label: '7. Troupe', icon: Users },
  { id: 'video', label: '8. Attr. Video', icon: Video },
  { id: 'audio', label: '9. Attr. Audio', icon: Mic },
  { id: 'location', label: '10. Location', icon: MapPin },
  { id: 'budget', label: '11. Budget', icon: DollarSign },
];

export const WorkspaceView: React.FC<WorkspaceViewProps> = ({
  project,
  customRoles,
  onAddCustomRole,
  onUpdateProject,
  initialModuleTab = 'spoglio',
}) => {
  const [activeTab, setActiveTab] = useState<string>(initialModuleTab);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const activeTabRef = useRef<HTMLButtonElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);

  useEffect(() => {
    if (initialModuleTab) {
      setActiveTab(initialModuleTab);
    }
  }, [initialModuleTab]);

  const checkScrollState = () => {
    if (scrollContainerRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current;
      setCanScrollLeft(scrollLeft > 2);
      setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 2);
    }
  };

  useEffect(() => {
    checkScrollState();
    const container = scrollContainerRef.current;
    if (container) {
      container.addEventListener('scroll', checkScrollState);
      window.addEventListener('resize', checkScrollState);
      return () => {
        container.removeEventListener('scroll', checkScrollState);
        window.removeEventListener('resize', checkScrollState);
      };
    }
  }, []);

  useEffect(() => {
    if (activeTabRef.current) {
      activeTabRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
        inline: 'center',
      });
    }
    checkScrollState();
  }, [activeTab]);

  const handleScroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const scrollAmount = direction === 'left' ? -220 : 220;
      scrollContainerRef.current.scrollBy({
        left: scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  if (!project) {
    return (
      <div className="p-8 text-center text-[#3D3B30]">
        <p className="text-sm text-[#6B705C]">Nessun progetto attivo selezionato.</p>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col p-4 md:p-6 text-[#3D3B30] space-y-5 overflow-y-auto select-none">
      {/* Module Tabs Header with Scroll Arrows */}
      <div className="bg-white p-2 rounded-2xl border border-[#E9EDC9] flex items-center gap-2 shrink-0 shadow-xs relative">
        <button
          onClick={() => handleScroll('left')}
          disabled={!canScrollLeft}
          title="Scorri a sinistra"
          aria-label="Scorri a sinistra"
          className={`p-2 rounded-xl border border-[#E9EDC9] transition-all shrink-0 ${
            canScrollLeft
              ? 'bg-[#F2F0E9] hover:bg-[#D4A373] hover:text-white text-[#3D3B30] cursor-pointer shadow-xs'
              : 'bg-[#F9F8F3] text-[#A3B18A]/50 border-transparent cursor-not-allowed opacity-40'
          }`}
        >
          <ChevronLeft className="w-4 h-4" />
        </button>

        <div
          ref={scrollContainerRef}
          className="flex-1 flex items-center gap-1.5 overflow-x-auto scroll-smooth [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none] py-0.5"
        >
          {MODULE_TABS.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                ref={isActive ? activeTabRef : null}
                onClick={() => setActiveTab(tab.id)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 ${
                  isActive
                    ? 'bg-[#D4A373] text-white shadow-xs scale-105'
                    : 'text-[#6B705C] hover:text-[#3D3B30] hover:bg-[#F2F0E9]'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        <button
          onClick={() => handleScroll('right')}
          disabled={!canScrollRight}
          title="Scorri a destra"
          aria-label="Scorri a destra"
          className={`p-2 rounded-xl border border-[#E9EDC9] transition-all shrink-0 ${
            canScrollRight
              ? 'bg-[#F2F0E9] hover:bg-[#D4A373] hover:text-white text-[#3D3B30] cursor-pointer shadow-xs'
              : 'bg-[#F9F8F3] text-[#A3B18A]/50 border-transparent cursor-not-allowed opacity-40'
          }`}
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Render Active Module */}
      <div className="flex-1">
        {activeTab === 'spoglio' && (
          <ScriptBreakdownModule project={project} onUpdateProject={onUpdateProject} />
        )}

        {activeTab === 'casting' && (
          <CastingModule project={project} onUpdateProject={onUpdateProject} />
        )}

        {activeTab === 'cast' && (
          <CastModule project={project} onNavigateToCasting={() => setActiveTab('casting')} />
        )}

        {activeTab === 'shotlist' && (
          <ShotListModule project={project} onUpdateProject={onUpdateProject} />
        )}

        {activeTab === 'costumi' && (
          <CostumesModule project={project} onUpdateProject={onUpdateProject} />
        )}

        {activeTab === 'props' && (
          <PropsModule project={project} onUpdateProject={onUpdateProject} />
        )}

        {activeTab === 'troupe' && (
          <TroupeModule
            project={project}
            customRoles={customRoles}
            onAddCustomRole={onAddCustomRole}
            onUpdateProject={onUpdateProject}
          />
        )}

        {activeTab === 'video' && (
          <EquipmentModule type="video" project={project} onUpdateProject={onUpdateProject} />
        )}

        {activeTab === 'audio' && (
          <EquipmentModule type="audio" project={project} onUpdateProject={onUpdateProject} />
        )}

        {activeTab === 'location' && (
          <LocationModule project={project} onUpdateProject={onUpdateProject} />
        )}

        {activeTab === 'budget' && (
          <BudgetModule project={project} onUpdateProject={onUpdateProject} />
        )}
      </div>
    </div>
  );
};
