import React, { useState } from 'react';
import { Search, ChevronDown, Bell, Clapperboard, Film, Sparkles, X } from 'lucide-react';
import { ProjectData, CalendarEvent } from '../types';

interface NavbarProps {
  currentView: 'dashboard' | 'workspace' | 'calendar' | 'ai' | 'profile';
  activeProject: ProjectData | null;
  projectsList: { id: string; titolo: string; tipo: string }[];
  onSelectProject: (id: string) => void;
  onOpenNewProjectModal: () => void;
  unreadRemindersCount: number;
  remindersList: CalendarEvent[];
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  activeProject,
  projectsList,
  onSelectProject,
  onOpenNewProjectModal,
  unreadRemindersCount,
  remindersList,
  searchQuery,
  onSearchChange,
}) => {
  const [showProjectDropdown, setShowProjectDropdown] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  return (
    <header className="h-16 px-6 flex items-center justify-between text-[#3D3B30] border-b border-[#E9EDC9] bg-[#F9F8F3] shrink-0">
      {/* Breadcrumb Path */}
      <div className="flex items-center gap-2 text-sm font-medium text-[#6B705C]">
        <span>Nuovo Cinema Indipendente</span>
        <span>/</span>
        <span className="text-[#2D332D] font-serif font-semibold capitalize">
          {currentView === 'dashboard'
            ? 'Overview Dashboard'
            : currentView === 'workspace'
            ? activeProject
              ? `Workspace: ${activeProject.titolo}`
              : 'Workspace'
            : currentView === 'calendar'
            ? 'Calendario Globale'
            : currentView === 'ai'
            ? 'Assistente AI Scenecraft'
            : 'Profilo Utente'}
        </span>
      </div>

      {/* Right Controls matching Image 3 */}
      <div className="flex items-center gap-3">
        {/* Search Pill Button */}
        <div className="relative">
          <div className="w-10 h-10 md:w-48 bg-white hover:bg-[#F2F0E9] transition-all rounded-full flex items-center px-3 gap-2 border border-[#CCD5AE] cursor-pointer shadow-xs">
            <Search className="w-4 h-4 text-[#6B705C] shrink-0" />
            <input
              type="text"
              placeholder="Cerca scene, cast..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="bg-transparent border-none outline-none text-xs text-[#3D3B30] placeholder-[#A3B18A] w-full hidden md:block"
            />
          </div>
        </div>

        {/* Project Selector Dropdown Pill matching "The Daily Grind, NY" */}
        <div className="relative">
          <button
            onClick={() => setShowProjectDropdown(!showProjectDropdown)}
            className="h-10 px-4 bg-white hover:bg-[#F2F0E9] border border-[#CCD5AE] rounded-full flex items-center gap-2 text-xs font-semibold text-[#3D3B30] transition-all shadow-xs"
          >
            <Clapperboard className="w-4 h-4 text-[#BC6C25]" />
            <span className="max-w-[160px] truncate font-medium">
              {activeProject ? activeProject.titolo : 'Seleziona Progetto'}
            </span>
            <ChevronDown className="w-3.5 h-3.5 text-[#6B705C]" />
          </button>

          {showProjectDropdown && (
            <div className="absolute right-0 mt-2 w-64 bg-white border border-[#E9EDC9] rounded-2xl shadow-xl p-2 z-50 animate-in fade-in zoom-in-95">
              <div className="px-3 py-2 text-[10px] font-bold tracking-wider text-[#6B705C] uppercase border-b border-[#E9EDC9] flex justify-between items-center">
                <span>I tuoi Progetti</span>
                <span className="text-[#BC6C25] font-semibold">{projectsList.length}</span>
              </div>
              <div className="max-h-56 overflow-y-auto py-1">
                {projectsList.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => {
                      onSelectProject(p.id);
                      setShowProjectDropdown(false);
                    }}
                    className={`w-full text-left px-3 py-2.5 rounded-xl text-xs flex items-center justify-between transition-all ${
                      activeProject?.id === p.id
                        ? 'bg-[#E9EDC9] text-[#2D332D] font-semibold'
                        : 'text-[#3D3B30] hover:bg-[#F2F0E9]'
                    }`}
                  >
                    <span className="truncate">{p.titolo}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#E5E2D8] text-[#5A584D]">
                      {p.tipo}
                    </span>
                  </button>
                ))}
              </div>
              <div className="pt-2 border-t border-[#E9EDC9]">
                <button
                  onClick={() => {
                    setShowProjectDropdown(false);
                    onOpenNewProjectModal();
                  }}
                  className="w-full py-2 bg-[#D4A373] hover:bg-[#BC6C25] text-white rounded-xl text-xs font-medium transition-all flex items-center justify-center gap-1.5 shadow-xs"
                >
                  <Sparkles className="w-3.5 h-3.5 text-white" />
                  + Nuovo Progetto
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Notifications Pill Button */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="w-10 h-10 bg-white hover:bg-[#F2F0E9] border border-[#CCD5AE] rounded-full flex items-center justify-center relative transition-all shadow-xs"
            title="Promemoria & Notifiche"
          >
            <Bell className="w-4 h-4 text-[#3D3B30]" />
            {unreadRemindersCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#BC6C25] text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-pulse">
                {unreadRemindersCount}
              </span>
            )}
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 bg-white border border-[#E9EDC9] rounded-2xl shadow-xl p-4 z-50 text-[#3D3B30] animate-in fade-in">
              <div className="flex items-center justify-between pb-3 border-b border-[#E9EDC9]">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#6B705C] flex items-center gap-1.5">
                  <Bell className="w-3.5 h-3.5 text-[#BC6C25]" /> Promemoria Calendario
                </h4>
                <button
                  onClick={() => setShowNotifications(false)}
                  className="text-[#6B705C] hover:text-[#3D3B30]"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="py-2 space-y-2 max-h-64 overflow-y-auto">
                {remindersList.length === 0 ? (
                  <p className="text-xs text-[#6B705C] py-4 text-center">
                    Nessun promemoria attivo per i prossimi eventi.
                  </p>
                ) : (
                  remindersList.map((rem) => (
                    <div
                      key={rem.id}
                      className="p-2.5 bg-[#F2F0E9] rounded-xl text-xs space-y-1 border border-[#E9EDC9]"
                    >
                      <div className="flex items-center justify-between font-semibold">
                        <span className="text-[#3D3B30]">{rem.titolo}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#D4A373]/20 text-[#BC6C25]">
                          {rem.tipo}
                        </span>
                      </div>
                      <div className="text-[11px] text-[#6B705C] flex items-center justify-between">
                        <span>
                          📅 {rem.data} {rem.ora ? `alle ${rem.ora}` : ''}
                        </span>
                      </div>
                      {rem.note && <p className="text-[10px] text-[#6B705C] italic">{rem.note}</p>}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
