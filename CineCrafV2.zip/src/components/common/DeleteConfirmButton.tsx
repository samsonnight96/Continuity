import React, { useState, useEffect } from 'react';
import { Trash2, AlertCircle } from 'lucide-react';

interface DeleteConfirmButtonProps {
  onConfirm: () => void;
  title?: string;
  className?: string;
}

export const DeleteConfirmButton: React.FC<DeleteConfirmButtonProps> = ({
  onConfirm,
  title = 'Elimina',
  className = '',
}) => {
  const [confirming, setConfirming] = useState(false);

  useEffect(() => {
    if (confirming) {
      const timer = setTimeout(() => setConfirming(false), 3000);
      return () => clearTimeout(timer);
    }
  }, [confirming]);

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirming) {
      onConfirm();
      setConfirming(false);
    } else {
      setConfirming(true);
    }
  };

  return (
    <button
      onClick={handleClick}
      className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all flex items-center gap-1 ${
        confirming
          ? 'bg-[#BC6C25] text-white animate-pulse'
          : 'bg-[#F2F0E9] text-[#6B705C] hover:text-[#BC6C25] hover:bg-[#D4A373]/20'
      } ${className}`}
      title={confirming ? 'Clicca di nuovo entro 3s per confermare' : title}
    >
      {confirming ? (
        <>
          <AlertCircle className="w-3.5 h-3.5" />
          <span>Confermi?</span>
        </>
      ) : (
        <>
          <Trash2 className="w-3.5 h-3.5" />
          <span>{title}</span>
        </>
      )}
    </button>
  );
};
