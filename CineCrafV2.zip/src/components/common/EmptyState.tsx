import React from 'react';
import { Sparkles, Plus } from 'lucide-react';

interface EmptyStateProps {
  message: string;
  onAction?: () => void;
  actionLabel?: string;
  icon?: React.ReactNode;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  message,
  onAction,
  actionLabel = '+ Aggiungi elemento',
  icon,
}) => {
  return (
    <div className="p-8 text-center bg-white rounded-2xl border border-dashed border-[#CCD5AE] my-4 flex flex-col items-center justify-center gap-3">
      <div className="w-12 h-12 rounded-full bg-[#E9EDC9] flex items-center justify-center text-[#BC6C25]">
        {icon || <Sparkles className="w-6 h-6" />}
      </div>
      <p className="text-xs md:text-sm text-[#6B705C] max-w-md">{message}</p>
      {onAction && (
        <button
          onClick={onAction}
          className="mt-2 px-4 py-2 bg-[#D4A373] hover:bg-[#BC6C25] text-white font-semibold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5"
        >
          <Plus className="w-4 h-4" />
          {actionLabel}
        </button>
      )}
    </div>
  );
};
