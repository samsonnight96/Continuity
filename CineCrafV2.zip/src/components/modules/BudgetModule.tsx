import React, { useState } from 'react';
import { DollarSign, Plus, RefreshCw, AlertTriangle, CheckCircle2, Edit3 } from 'lucide-react';
import {
  ProjectData,
  BudgetItem,
  BudgetCategory,
  LinkedBudgetEntry,
} from '../../types';
import { DeleteConfirmButton } from '../common/DeleteConfirmButton';
import { EmptyState } from '../common/EmptyState';

interface BudgetModuleProps {
  project: ProjectData;
  onUpdateProject: (updated: Partial<ProjectData>) => void;
}

const FIXED_CATEGORIES: BudgetCategory[] = ['Cast', 'Troupe', 'Fabbisogno Set', 'Post Produzione'];

export const BudgetModule: React.FC<BudgetModuleProps> = ({ project, onUpdateProject }) => {
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const [categoria, setCategoria] = useState<BudgetCategory>('Cast');
  const [voce, setVoce] = useState('');
  const [quantita, setQuantita] = useState<number>(1);
  const [importoUnitario, setImportoUnitario] = useState<number>(500);
  const [giorni, setGiorni] = useState<number>(1);
  const [note, setNote] = useState('');

  // Upstream Live Calculated Totals
  const currentCostumiTotal = project.costumi.reduce((acc, c) => acc + (c.costo || 0), 0);
  const currentPropsTotal = project.scenografia.reduce((acc, p) => acc + (p.costo || 0), 0);
  const currentVideoTotal = project.attrezzaturaVideo.reduce(
    (acc, v) => acc + v.costoGiornaliero * v.giornate,
    0
  );
  const currentAudioTotal = project.attrezzaturaAudio.reduce(
    (acc, a) => acc + a.costoGiornaliero * a.giornate,
    0
  );

  const upstreamEntries = [
    {
      type: 'costumi' as const,
      label: 'Costumi da Spoglio',
      category: 'Fabbisogno Set' as BudgetCategory,
      currentAmount: currentCostumiTotal,
    },
    {
      type: 'scenografia' as const,
      label: 'Scenografia & Props',
      category: 'Fabbisogno Set' as BudgetCategory,
      currentAmount: currentPropsTotal,
    },
    {
      type: 'video' as const,
      label: 'Noleggio Attrezzatura Video',
      category: 'Troupe' as BudgetCategory,
      currentAmount: currentVideoTotal,
    },
    {
      type: 'audio' as const,
      label: 'Noleggio Attrezzatura Audio',
      category: 'Troupe' as BudgetCategory,
      currentAmount: currentAudioTotal,
    },
  ];

  // Helper for sync button
  const handleSyncLinkedEntry = (type: 'costumi' | 'scenografia' | 'video' | 'audio', currentAmount: number, label: string, category: BudgetCategory) => {
    let linked = [...(project.linkedBudgetEntries || [])];
    const idx = linked.findIndex((e) => e.type === type);

    if (idx !== -1) {
      linked[idx] = { ...linked[idx], savedAmount: currentAmount };
    } else {
      linked.push({
        id: 'lbdg_' + Date.now(),
        type,
        label,
        category,
        savedAmount: currentAmount,
      });
    }

    onUpdateProject({ linkedBudgetEntries: linked });
  };

  const handleOpenAddManual = () => {
    setEditingId(null);
    setCategoria('Cast');
    setVoce('');
    setQuantita(1);
    setImportoUnitario(500);
    setGiorni(1);
    setNote('');
    setShowModal(true);
  };

  const handleOpenEditManual = (b: BudgetItem) => {
    setEditingId(b.id);
    setCategoria(b.categoria);
    setVoce(b.voce);
    setQuantita(b.quantita);
    setImportoUnitario(b.importoUnitario);
    setGiorni(b.giorni);
    setNote(b.note || '');
    setShowModal(true);
  };

  const handleSaveManual = () => {
    const itemData: BudgetItem = {
      id: editingId || 'bdg_' + Date.now(),
      categoria,
      voce,
      quantita: Number(quantita),
      importoUnitario: Number(importoUnitario),
      giorni: Number(giorni),
      note,
    };

    let updatedList = [...project.budget];
    if (editingId) {
      updatedList = updatedList.map((i) => (i.id === editingId ? itemData : i));
    } else {
      updatedList.unshift(itemData);
    }

    onUpdateProject({ budget: updatedList });
    setShowModal(false);
  };

  const handleDeleteManual = (id: string) => {
    const updated = project.budget.filter((i) => i.id !== id);
    onUpdateProject({ budget: updated });
  };

  const handleDeleteLinked = (type: string) => {
    const updated = (project.linkedBudgetEntries || []).filter((e) => e.type !== type);
    onUpdateProject({ linkedBudgetEntries: updated });
  };

  // Grand Total Calculation
  const manualTotalSum = project.budget.reduce(
    (acc, item) => acc + item.quantita * item.importoUnitario * item.giorni,
    0
  );

  const linkedTotalSum = (project.linkedBudgetEntries || []).reduce(
    (acc, item) => acc + item.savedAmount,
    0
  );

  const grandTotalProject = manualTotalSum + linkedTotalSum;

  return (
    <div className="space-y-6 text-[#3D3B30]">
      {/* Module Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-[#E9EDC9] shadow-sm">
        <div>
          <h2 className="text-lg font-bold font-serif flex items-center gap-2 text-[#2D332D]">
            <DollarSign className="w-5 h-5 text-[#BC6C25]" /> Modulo 11 — Budget Preventivo
          </h2>
          <p className="text-xs text-[#6B705C] mt-1">
            Organizzato nelle 4 categorie di costo del cinema indipendente con collegamenti trasversali agli altri moduli.
          </p>
        </div>

        <button
          onClick={handleOpenAddManual}
          className="px-4 py-2.5 bg-[#D4A373] hover:bg-[#BC6C25] text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 shrink-0"
        >
          <Plus className="w-4 h-4" /> Aggiungi Voce Manuale
        </button>
      </div>

      {/* Linked Automatic Totals Section */}
      <div className="bg-white p-5 rounded-2xl border border-[#E9EDC9] space-y-4 shadow-sm">
        <h3 className="text-xs font-bold uppercase tracking-wider text-[#6B705C] flex items-center gap-2 font-serif">
          <RefreshCw className="w-4 h-4 text-[#BC6C25]" /> Collegamenti Automatici dagli Altri Moduli
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {upstreamEntries.map((up) => {
            const savedEntry = (project.linkedBudgetEntries || []).find((e) => e.type === up.type);
            const isAdded = !!savedEntry;
            const isOutOfSync = isAdded && savedEntry.savedAmount !== up.currentAmount;

            return (
              <div
                key={up.type}
                className="bg-[#F9F8F3] p-4 rounded-xl border border-[#E9EDC9] space-y-3 flex flex-col justify-between"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-[#2D332D] text-xs font-serif">{up.label}</h4>
                    <p className="text-[10px] text-[#6B705C]">
                      Destinazione: <span className="text-[#BC6C25] font-semibold">{up.category}</span>
                    </p>
                  </div>

                  <div className="text-right">
                    <span className="text-xs text-[#6B705C] font-mono block">Valore Corrente Modulo</span>
                    <span className="text-sm font-black text-[#2D332D]">
                      €{up.currentAmount.toLocaleString('it-IT')}
                    </span>
                  </div>
                </div>

                {/* Status & Sync Button */}
                <div className="flex items-center justify-between pt-2 border-t border-[#E9EDC9] text-xs">
                  {isOutOfSync && (
                    <span className="text-[10px] text-[#BC6C25] flex items-center gap-1 font-semibold">
                      <AlertTriangle className="w-3.5 h-3.5" /> Salvato: €{savedEntry.savedAmount} (non aggiornato!)
                    </span>
                  )}
                  {!isAdded && <span className="text-[10px] text-[#A3B18A]">Non ancora aggiunto al budget</span>}
                  {isAdded && !isOutOfSync && (
                    <span className="text-[10px] text-[#2D332D] flex items-center gap-1 font-semibold bg-[#A3B18A]/20 px-2 py-0.5 rounded-full">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#A3B18A]" /> Sincronizzato (€{savedEntry.savedAmount})
                    </span>
                  )}

                  <button
                    onClick={() => handleSyncLinkedEntry(up.type, up.currentAmount, up.label, up.category)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ${
                      isOutOfSync
                        ? 'bg-[#BC6C25] text-white animate-pulse'
                        : isAdded
                        ? 'bg-[#E5E2D8] hover:bg-[#CCD5AE] text-[#3D3B30]'
                        : 'bg-[#D4A373] text-white hover:bg-[#BC6C25]'
                    }`}
                  >
                    <RefreshCw className="w-3 h-3" />
                    {isAdded ? (isOutOfSync ? 'Aggiorna nel Budget' : 'Risincronizza') : 'Aggiungi al Budget'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Budget Table Grouped by Category */}
      <div className="space-y-6">
        {FIXED_CATEGORIES.map((cat) => {
          const manualItemsForCat = project.budget.filter((b) => b.categoria === cat);
          const linkedItemsForCat = (project.linkedBudgetEntries || []).filter((e) => e.category === cat);

          const manualSubtotal = manualItemsForCat.reduce(
            (acc, b) => acc + b.quantita * b.importoUnitario * b.giorni,
            0
          );
          const linkedSubtotal = linkedItemsForCat.reduce((acc, e) => acc + e.savedAmount, 0);
          const categorySubtotal = manualSubtotal + linkedSubtotal;

          return (
            <div key={cat} className="bg-white rounded-2xl border border-[#E9EDC9] overflow-hidden shadow-sm">
              <div className="bg-[#F2F0E9] p-4 flex items-center justify-between border-b border-[#E9EDC9]">
                <h3 className="text-sm font-black text-[#2D332D] uppercase tracking-wider font-serif">{cat}</h3>
                <span className="text-xs font-bold text-[#3D3B30] bg-[#CCD5AE]/40 px-3 py-1 rounded-full">
                  Subtotale: €{categorySubtotal.toLocaleString('it-IT')}
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-[#3D3B30]">
                  <thead className="bg-[#F9F8F3] text-[#6B705C] uppercase tracking-wider text-[10px] border-b border-[#E9EDC9]">
                    <tr>
                      <th className="p-3.5 font-serif">Voce</th>
                      <th className="p-3.5 font-serif">Quantità</th>
                      <th className="p-3.5 font-serif">Importo Unitario (€)</th>
                      <th className="p-3.5 font-serif">Giorni</th>
                      <th className="p-3.5 font-serif">Preventivo Riga (€)</th>
                      <th className="p-3.5 font-serif">Note</th>
                      <th className="p-3.5 text-right font-serif">Azioni</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E9EDC9]">
                    {/* Linked items rows */}
                    {linkedItemsForCat.map((le) => (
                      <tr key={le.id} className="bg-[#E9EDC9]/20 font-semibold">
                        <td className="p-3.5 text-[#2D332D] flex items-center gap-2">
                          <span className="text-[10px] px-2 py-0.5 rounded bg-[#E9EDC9] text-[#2D332D] font-bold">
                            COLLEGATO
                          </span>
                          {le.label}
                        </td>
                        <td className="p-3.5">1</td>
                        <td className="p-3.5">€{le.savedAmount.toLocaleString('it-IT')}</td>
                        <td className="p-3.5">1</td>
                        <td className="p-3.5 font-bold text-[#BC6C25]">€{le.savedAmount.toLocaleString('it-IT')}</td>
                        <td className="p-3.5 text-[#6B705C]">Calcolato dagli altri moduli</td>
                        <td className="p-3.5 text-right">
                          <DeleteConfirmButton onConfirm={() => handleDeleteLinked(le.type)} />
                        </td>
                      </tr>
                    ))}

                    {/* Manual items rows */}
                    {manualItemsForCat.map((b) => {
                      const rowTotal = b.quantita * b.importoUnitario * b.giorni;
                      return (
                        <tr key={b.id} className="hover:bg-[#F9F8F3] transition-colors">
                          <td className="p-3.5 font-bold text-[#2D332D]">{b.voce}</td>
                          <td className="p-3.5">{b.quantita}</td>
                          <td className="p-3.5">€{b.importoUnitario}</td>
                          <td className="p-3.5">{b.giorni}</td>
                          <td className="p-3.5 font-bold text-[#2D332D]">€{rowTotal.toLocaleString('it-IT')}</td>
                          <td className="p-3.5 text-[#6B705C]">{b.note || '—'}</td>
                          <td className="p-3.5 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                onClick={() => handleOpenEditManual(b)}
                                className="p-1.5 rounded-lg bg-[#F2F0E9] hover:bg-[#E5E2D8] text-[#3D3B30]"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                              <DeleteConfirmButton onConfirm={() => handleDeleteManual(b.id)} />
                            </div>
                          </td>
                        </tr>
                      );
                    })}

                    {manualItemsForCat.length === 0 && linkedItemsForCat.length === 0 && (
                      <tr>
                        <td colSpan={7} className="p-4 text-center text-[#A3B18A] italic">
                          Nessuna voce per la categoria {cat}.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          );
        })}
      </div>

      {/* GRAND TOTAL BAR */}
      <div className="bg-[#2D332D] text-[#FAFAF7] p-6 rounded-2xl shadow-md flex items-center justify-between border border-[#CCD5AE]">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-[#CCD5AE]">
            PREVENTIVO COMPLESSIVO DEL PROGETTO
          </span>
          <h2 className="text-3xl font-black mt-1 text-[#E9EDC9] font-serif">
            TOTALE PROGETTO: €{grandTotalProject.toLocaleString('it-IT')}
          </h2>
        </div>
      </div>

      {/* Manual Item Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-[#E9EDC9] rounded-2xl w-full max-w-lg p-6 space-y-4 shadow-2xl animate-in fade-in text-[#3D3B30]">
            <h3 className="text-base font-bold font-serif text-[#2D332D] border-b border-[#E9EDC9] pb-3">
              {editingId ? 'Modifica Voce Budget' : 'Nuova Voce Manuale Budget'}
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Categoria *</label>
                <select
                  value={categoria}
                  onChange={(e) => setCategoria(e.target.value as BudgetCategory)}
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                >
                  {FIXED_CATEGORIES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Voce di Spesa *</label>
                <input
                  type="text"
                  value={voce}
                  onChange={(e) => setVoce(e.target.value)}
                  placeholder="es. Compenso Montaggio Video"
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-[#6B705C] block mb-1 font-semibold">Quantità</label>
                  <input
                    type="number"
                    value={quantita}
                    onChange={(e) => setQuantita(Number(e.target.value))}
                    className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                  />
                </div>

                <div>
                  <label className="text-[#6B705C] block mb-1 font-semibold">Importo Unit. (€)</label>
                  <input
                    type="number"
                    value={importoUnitario}
                    onChange={(e) => setImportoUnitario(Number(e.target.value))}
                    className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                  />
                </div>

                <div>
                  <label className="text-[#6B705C] block mb-1 font-semibold">Giorni (default 1)</label>
                  <input
                    type="number"
                    value={giorni}
                    onChange={(e) => setGiorni(Number(e.target.value))}
                    className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                  />
                </div>
              </div>

              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Note</label>
                <input
                  type="text"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Contratto, fornitore..."
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
              </div>

              <div className="p-3 bg-[#F2F0E9] border border-[#E9EDC9] rounded-xl font-bold text-[#3D3B30] flex justify-between">
                <span>Totale Riga:</span>
                <span className="text-[#BC6C25]">
                  €{(quantita * importoUnitario * giorni).toLocaleString('it-IT')}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#E9EDC9]">
              <button onClick={() => setShowModal(false)} className="px-4 py-2 bg-[#E5E2D8] hover:bg-[#CCD5AE] text-[#3D3B30] rounded-xl text-xs font-semibold">
                Annulla
              </button>
              <button onClick={handleSaveManual} className="px-4 py-2 bg-[#D4A373] hover:bg-[#BC6C25] text-white rounded-xl text-xs font-bold">
                Salva Voce
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
