import React from 'react';
import { Users, Link as LinkIcon, Phone, ArrowUpRight } from 'lucide-react';
import { ProjectData } from '../../types';
import { EmptyState } from '../common/EmptyState';

interface CastModuleProps {
  project: ProjectData;
  onNavigateToCasting: () => void;
}

export const CastModule: React.FC<CastModuleProps> = ({ project, onNavigateToCasting }) => {
  // Filter confirmed candidates
  const confirmedCast = project.casting.filter((c) => c.stato === 'Confermato');

  // Compute scenes for each character from Spoglio tags
  const getScenesForRole = (roleName: string) => {
    if (!roleName) return '—';
    const matchingTags = project.scriptTags.filter(
      (t) =>
        t.categoria === 'Personaggio' &&
        t.testo.toLowerCase().trim() === roleName.toLowerCase().trim()
    );

    const sceneNumbers = Array.from(
      new Set(matchingTags.map((t) => t.scenaNumero || '1').filter(Boolean))
    );

    return sceneNumbers.length > 0 ? sceneNumbers.sort((a, b) => Number(a) - Number(b)).join(', ') : '1';
  };

  return (
    <div className="space-y-6 text-[#3D3B30]">
      {/* Module Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-[#E9EDC9] shadow-sm">
        <div>
          <h2 className="text-lg font-bold font-serif flex items-center gap-2 text-[#2D332D]">
            <Users className="w-5 h-5 text-[#BC6C25]" /> Modulo 03 — Cast Confermato
          </h2>
          <p className="text-xs text-[#6B705C] mt-1">
            Vista automatica derivata dal Modulo Casting. Elenca tutti gli attori con stato "Confermato" e le loro scene di presenza rilevate dallo spoglio.
          </p>
        </div>

        <button
          onClick={onNavigateToCasting}
          className="px-4 py-2.5 bg-[#E5E2D8] hover:bg-[#CCD5AE] text-[#3D3B30] font-semibold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 shrink-0"
        >
          <span>Gestisci in Casting</span>
          <ArrowUpRight className="w-4 h-4" />
        </button>
      </div>

      {/* Cast Table */}
      {confirmedCast.length === 0 ? (
        <EmptyState
          message="Nessun attore ancora confermato. Vai nel Modulo 02 (Casting) e imposta lo Stato di un candidato su 'Confermato'."
          onAction={onNavigateToCasting}
          actionLabel="Vai al Modulo Casting"
        />
      ) : (
        <div className="bg-white rounded-2xl border border-[#E9EDC9] overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-[#3D3B30]">
              <thead className="bg-[#F2F0E9] text-[#6B705C] uppercase tracking-wider text-[10px] border-b border-[#E9EDC9]">
                <tr>
                  <th className="p-4 font-serif whitespace-nowrap">Ruolo</th>
                  <th className="p-4 font-serif whitespace-nowrap">Attore / Candidato</th>
                  <th className="p-4 font-serif whitespace-nowrap">Contatti</th>
                  <th className="p-4 font-serif whitespace-nowrap">Showreel / Materiale</th>
                  <th className="p-4 font-serif whitespace-nowrap">Scene di Presenza (Spoglio)</th>
                  <th className="p-4 text-right font-serif whitespace-nowrap">Azione</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E9EDC9]">
                {confirmedCast.map((c) => {
                  const scenes = getScenesForRole(c.ruoloCercato);
                  return (
                    <tr key={c.id} className="hover:bg-[#F9F8F3] transition-colors">
                      <td className="p-4 font-bold text-[#2D332D] whitespace-nowrap">
                        <span className="px-2.5 py-1 rounded-md bg-[#E9EDC9] text-[#2D332D] font-bold inline-block whitespace-nowrap">
                          {c.ruoloCercato}
                        </span>
                      </td>
                      <td className="p-4 font-bold text-[#3D3B30] whitespace-nowrap">{c.candidato}</td>
                      <td className="p-4 text-[#6B705C] whitespace-nowrap">
                        {c.contatti ? (
                          <span className="flex items-center gap-1">
                            <Phone className="w-3 h-3 text-[#A3B18A]" /> {c.contatti}
                          </span>
                        ) : (
                          '—'
                        )}
                      </td>
                      <td className="p-4 whitespace-nowrap">
                        {c.linkDrive ? (
                          <a
                            href={c.linkDrive}
                            target="_blank"
                            rel="noreferrer"
                            className="text-[#BC6C25] hover:underline inline-flex items-center gap-1 font-semibold whitespace-nowrap"
                          >
                            <LinkIcon className="w-3 h-3" /> Showreel
                          </a>
                        ) : (
                          '—'
                        )}
                      </td>
                      <td className="p-4 whitespace-nowrap">
                        <span className="px-2 py-0.5 rounded-full bg-[#F2F0E9] text-[#3D3B30] font-mono font-bold inline-block whitespace-nowrap">
                          Scena/e: {scenes}
                        </span>
                      </td>
                      <td className="p-4 text-right">
                        <button
                          onClick={onNavigateToCasting}
                          className="px-2.5 py-1 bg-[#F2F0E9] hover:bg-[#E5E2D8] text-[#3D3B30] rounded-lg text-xs"
                        >
                          Modifica
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
