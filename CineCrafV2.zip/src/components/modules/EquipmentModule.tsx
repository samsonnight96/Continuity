import React, { useState } from 'react';
import { Video, Mic, Plus, Edit3 } from 'lucide-react';
import { ProjectData, EquipmentItem, EquipmentStatus } from '../../types';
import { DeleteConfirmButton } from '../common/DeleteConfirmButton';
import { EmptyState } from '../common/EmptyState';

interface EquipmentModuleProps {
  type: 'video' | 'audio';
  project: ProjectData;
  onUpdateProject: (updated: Partial<ProjectData>) => void;
}

const EQUIPMENT_STATUSES: EquipmentStatus[] = ['In possesso', 'Da noleggiare'];

export const EquipmentModule: React.FC<EquipmentModuleProps> = ({
  type,
  project,
  onUpdateProject,
}) => {
  const isVideo = type === 'video';
  const list = isVideo ? project.attrezzaturaVideo : project.attrezzaturaAudio;

  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const [nome, setNome] = useState('');
  const [stato, setStato] = useState<EquipmentStatus>('Da noleggiare');
  const [costoGiornaliero, setCostoGiornaliero] = useState<number>(150);
  const [giornate, setGiornate] = useState<number>(10);

  const handleOpenAdd = () => {
    setEditingId(null);
    setNome('');
    setStato('Da noleggiare');
    setCostoGiornaliero(150);
    setGiornate(10);
    setShowModal(true);
  };

  const handleOpenEdit = (item: EquipmentItem) => {
    setEditingId(item.id);
    setNome(item.nome);
    setStato(item.stato);
    setCostoGiornaliero(item.costoGiornaliero);
    setGiornate(item.giornate);
    setShowModal(true);
  };

  const handleSave = () => {
    const itemData: EquipmentItem = {
      id: editingId || (isVideo ? 'vid_' : 'aud_') + Date.now(),
      nome,
      stato,
      costoGiornaliero: Number(costoGiornaliero),
      giornate: Number(giornate),
    };

    let updatedList = [...list];
    if (editingId) {
      updatedList = updatedList.map((i) => (i.id === editingId ? itemData : i));
    } else {
      updatedList.unshift(itemData);
    }

    if (isVideo) {
      onUpdateProject({ attrezzaturaVideo: updatedList });
    } else {
      onUpdateProject({ attrezzaturaAudio: updatedList });
    }
    setShowModal(false);
  };

  const handleDelete = (id: string) => {
    const updated = list.filter((i) => i.id !== id);
    if (isVideo) {
      onUpdateProject({ attrezzaturaVideo: updated });
    } else {
      onUpdateProject({ attrezzaturaAudio: updated });
    }
  };

  const totalRentalCost = list.reduce((acc, i) => acc + i.costoGiornaliero * i.giornate, 0);

  return (
    <div className="space-y-6 text-[#3D3B30]">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-[#E9EDC9] shadow-sm">
        <div>
          <h2 className="text-lg font-bold font-serif flex items-center gap-2 text-[#2D332D]">
            {isVideo ? (
              <Video className="w-5 h-5 text-[#BC6C25]" />
            ) : (
              <Mic className="w-5 h-5 text-[#BC6C25]" />
            )}
            Modulo {isVideo ? '08' : '09'} — Attrezzatura {isVideo ? 'Video' : 'Audio'}
          </h2>
          <p className="text-xs text-[#6B705C] mt-1">
            Gestisci la lista del parco macchine e dei noleggi {isVideo ? 'camera e lenti' : 'audio e radiomicrofoni'}. Totale Noleggi: €
            {totalRentalCost.toLocaleString('it-IT')}
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-4 py-2.5 bg-[#D4A373] hover:bg-[#BC6C25] text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 shrink-0"
        >
          <Plus className="w-4 h-4" /> Aggiungi Attrezzatura
        </button>
      </div>

      {list.length === 0 ? (
        <EmptyState
          message={`Nessuna attrezzatura ${isVideo ? 'video' : 'audio'} presente.`}
          onAction={handleOpenAdd}
        />
      ) : (
        <div className="bg-white rounded-2xl border border-[#E9EDC9] overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-[#3D3B30]">
              <thead className="bg-[#F2F0E9] text-[#6B705C] uppercase tracking-wider text-[10px] border-b border-[#E9EDC9]">
                <tr>
                  <th className="p-4 font-serif whitespace-nowrap">Nome Attrezzatura / Kit</th>
                  <th className="p-4 font-serif whitespace-nowrap">Stato</th>
                  <th className="p-4 font-serif whitespace-nowrap">Costo Giornaliero (€)</th>
                  <th className="p-4 font-serif whitespace-nowrap">Giornate Noleggio</th>
                  <th className="p-4 font-serif whitespace-nowrap">Costo Totale Calcolato (€)</th>
                  <th className="p-4 text-right font-serif whitespace-nowrap">Azioni</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E9EDC9]">
                {list.map((item) => {
                  const calculatedTotal = item.costoGiornaliero * item.giornate;
                  return (
                    <tr key={item.id} className="hover:bg-[#F9F8F3] transition-colors">
                      <td className="p-4 font-bold text-[#2D332D] whitespace-nowrap">{item.nome}</td>
                      <td className="p-4 whitespace-nowrap">
                        <span
                          className={`px-2.5 py-1 rounded-full text-[10px] font-bold inline-block whitespace-nowrap ${
                            item.stato === 'In possesso'
                              ? 'bg-[#A3B18A]/30 text-[#2D332D]'
                              : 'bg-[#D4A373]/30 text-[#BC6C25]'
                          }`}
                        >
                          {item.stato}
                        </span>
                      </td>
                      <td className="p-4 text-[#6B705C] whitespace-nowrap">€{item.costoGiornaliero}</td>
                      <td className="p-4 text-[#6B705C] whitespace-nowrap">{item.giornate} gg</td>
                      <td className="p-4 font-black text-[#2D332D] text-sm whitespace-nowrap">
                        €{calculatedTotal.toLocaleString('it-IT')}
                      </td>
                      <td className="p-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => handleOpenEdit(item)}
                            className="p-1.5 rounded-lg bg-[#F2F0E9] hover:bg-[#E5E2D8] text-[#3D3B30]"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <DeleteConfirmButton onConfirm={() => handleDelete(item.id)} />
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-[#E9EDC9] rounded-2xl w-full max-w-lg p-6 space-y-4 shadow-2xl animate-in fade-in text-[#3D3B30]">
            <h3 className="text-base font-bold font-serif text-[#2D332D] border-b border-[#E9EDC9] pb-3">
              {editingId ? 'Modifica Attrezzatura' : `Nuova Attrezzatura ${isVideo ? 'Video' : 'Audio'}`}
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Nome Attrezzatura / Kit *</label>
                <input
                  type="text"
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  placeholder={isVideo ? 'es. ARRI Alexa Mini LF' : 'es. Sound Devices 833'}
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
              </div>

              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Stato *</label>
                <select
                  value={stato}
                  onChange={(e) => setStato(e.target.value as any)}
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                >
                  {EQUIPMENT_STATUSES.map((st) => (
                    <option key={st} value={st}>
                      {st}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[#6B705C] block mb-1 font-semibold">Costo Giornaliero (€)</label>
                  <input
                    type="number"
                    value={costoGiornaliero}
                    onChange={(e) => setCostoGiornaliero(Number(e.target.value))}
                    className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                  />
                </div>

                <div>
                  <label className="text-[#6B705C] block mb-1 font-semibold">Giornate di Noleggio</label>
                  <input
                    type="number"
                    value={giornate}
                    onChange={(e) => setGiornate(Number(e.target.value))}
                    className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                  />
                </div>
              </div>

              <div className="p-3 bg-[#F2F0E9] border border-[#E9EDC9] rounded-xl text-[#3D3B30] font-semibold flex justify-between items-center">
                <span>Costo Totale Calcolato:</span>
                <span className="text-sm font-black text-[#BC6C25]">
                  €{(costoGiornaliero * giornate).toLocaleString('it-IT')}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#E9EDC9]">
              <button onClick={() => setShowModal(false)} className="px-4 py-2 bg-[#E5E2D8] hover:bg-[#CCD5AE] text-[#3D3B30] rounded-xl text-xs font-semibold">
                Annulla
              </button>
              <button onClick={handleSave} className="px-4 py-2 bg-[#D4A373] hover:bg-[#BC6C25] text-white rounded-xl text-xs font-bold">
                Salva Attrezzatura
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
