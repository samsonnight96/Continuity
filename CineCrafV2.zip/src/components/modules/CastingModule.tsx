import React, { useState } from 'react';
import { UserCheck, Plus, Star, Link as LinkIcon, Phone, MessageSquare, Edit3 } from 'lucide-react';
import { ProjectData, CastingCandidate, CastingStatus } from '../../types';
import { DeleteConfirmButton } from '../common/DeleteConfirmButton';
import { EmptyState } from '../common/EmptyState';

interface CastingModuleProps {
  project: ProjectData;
  onUpdateProject: (updated: Partial<ProjectData>) => void;
}

const CASTING_STATUSES: CastingStatus[] = [
  'Da contattare',
  'Fissare provino',
  'Provino fissato',
  'Provinato',
  'Secondo provino',
  'Terzo provino',
  'Confermato',
  'Scartato',
];

export const CastingModule: React.FC<CastingModuleProps> = ({ project, onUpdateProject }) => {
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form fields
  const [ruoloCercato, setRuoloCercato] = useState('');
  const [candidato, setCandidato] = useState('');
  const [stato, setStato] = useState<CastingStatus>('Da contattare');
  const [voto, setVoto] = useState<number>(3);
  const [contatti, setContatti] = useState('');
  const [linkDrive, setLinkDrive] = useState('');
  const [commento, setCommento] = useState('');

  // Extract character role suggestions from Spoglio tags
  const roleSuggestions = Array.from(
    new Set(
      project.scriptTags
        .filter((t) => t.categoria === 'Personaggio')
        .map((t) => t.testo)
    )
  );

  const handleOpenAddModal = () => {
    setEditingId(null);
    setRuoloCercato(roleSuggestions[0] || '');
    setCandidato('');
    setStato('Da contattare');
    setVoto(3);
    setContatti('');
    setLinkDrive('');
    setCommento('');
    setShowModal(true);
  };

  const handleOpenEditModal = (c: CastingCandidate) => {
    setEditingId(c.id);
    setRuoloCercato(c.ruoloCercato);
    setCandidato(c.candidato);
    setStato(c.stato);
    setVoto(c.voto);
    setContatti(c.contatti);
    setLinkDrive(c.linkDrive);
    setCommento(c.commento);
    setShowModal(true);
  };

  const handleSave = () => {
    const candidateData: CastingCandidate = {
      id: editingId || 'cst_' + Date.now(),
      ruoloCercato,
      candidato,
      stato,
      voto,
      contatti,
      linkDrive,
      commento,
    };

    let updatedCasting = [...project.casting];
    if (editingId) {
      updatedCasting = updatedCasting.map((item) => (item.id === editingId ? candidateData : item));
    } else {
      updatedCasting.unshift(candidateData);
    }

    onUpdateProject({ casting: updatedCasting });
    setShowModal(false);
  };

  const handleDelete = (id: string) => {
    const updated = project.casting.filter((c) => c.id !== id);
    onUpdateProject({ casting: updated });
  };

  return (
    <div className="space-y-6 text-[#3D3B30]">
      {/* Module Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-[#E9EDC9] shadow-sm">
        <div>
          <h2 className="text-lg font-bold font-serif flex items-center gap-2 text-[#2D332D]">
            <UserCheck className="w-5 h-5 text-[#BC6C25]" /> Modulo 02 — Casting Pipeline
          </h2>
          <p className="text-xs text-[#6B705C] mt-1">
            Gestisci la valutazione dei candidati per ciascun ruolo dello spoglio. I candidati con stato "Confermato" popoleranno il Cast!
          </p>
        </div>

        <button
          onClick={handleOpenAddModal}
          className="px-4 py-2.5 bg-[#D4A373] hover:bg-[#BC6C25] text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 shrink-0"
        >
          <Plus className="w-4 h-4" /> Aggiungi Candidato
        </button>
      </div>

      {/* Candidates Table */}
      {project.casting.length === 0 ? (
        <EmptyState
          message="Nessun candidato ancora. Aggiungi il primo attore da valutare per i ruoli della sceneggiatura."
          onAction={handleOpenAddModal}
        />
      ) : (
        <div className="bg-white rounded-2xl border border-[#E9EDC9] overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-[#3D3B30]">
              <thead className="bg-[#F2F0E9] text-[#6B705C] uppercase tracking-wider text-[10px] border-b border-[#E9EDC9]">
                <tr>
                  <th className="p-4 font-serif whitespace-nowrap">Ruolo Cercato</th>
                  <th className="p-4 font-serif whitespace-nowrap">Candidato</th>
                  <th className="p-4 font-serif whitespace-nowrap">Stato</th>
                  <th className="p-4 font-serif whitespace-nowrap">Voto</th>
                  <th className="p-4 font-serif whitespace-nowrap">Contatti</th>
                  <th className="p-4 font-serif whitespace-nowrap">Link Showreel</th>
                  <th className="p-4 text-right font-serif whitespace-nowrap">Azioni</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E9EDC9]">
                {project.casting.map((c) => (
                  <tr key={c.id} className="hover:bg-[#F9F8F3] transition-colors">
                    <td className="p-4 font-bold text-[#2D332D] whitespace-nowrap">
                      <span className="px-2.5 py-1 rounded-md bg-[#E9EDC9] text-[#2D332D] inline-block whitespace-nowrap">
                        {c.ruoloCercato || 'Ruolo non specificato'}
                      </span>
                    </td>
                    <td className="p-4 font-medium text-[#3D3B30] whitespace-nowrap">{c.candidato || '—'}</td>
                    <td className="p-4 whitespace-nowrap">
                      <span
                        className={`px-2.5 py-1 rounded-full text-[10px] font-bold inline-block whitespace-nowrap ${
                          c.stato === 'Confermato'
                            ? 'bg-[#A3B18A]/30 text-[#2D332D] border border-[#A3B18A]'
                            : c.stato === 'Scartato'
                            ? 'bg-[#BC6C25]/20 text-[#BC6C25] border border-[#BC6C25]/30'
                            : 'bg-[#D4A373]/20 text-[#BC6C25] border border-[#D4A373]/40'
                        }`}
                      >
                        {c.stato}
                      </span>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center gap-1 text-[#D4A373]">
                        {Array.from({ length: 5 }).map((_, idx) => (
                          <Star
                            key={idx}
                            className={`w-3.5 h-3.5 ${
                              idx < c.voto ? 'fill-[#D4A373] text-[#D4A373]' : 'text-[#CCD5AE]'
                            }`}
                          />
                        ))}
                      </div>
                    </td>
                    <td className="p-4 text-[#6B705C]">
                      {c.contatti ? (
                        <span className="flex items-center gap-1">
                          <Phone className="w-3 h-3 text-[#A3B18A]" /> {c.contatti}
                        </span>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td className="p-4">
                      {c.linkDrive ? (
                        <a
                          href={c.linkDrive}
                          target="_blank"
                          rel="noreferrer"
                          className="text-[#BC6C25] hover:underline flex items-center gap-1 font-semibold"
                        >
                          <LinkIcon className="w-3 h-3" /> Showreel
                        </a>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td className="p-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => handleOpenEditModal(c)}
                          className="p-1.5 rounded-lg bg-[#F2F0E9] hover:bg-[#E5E2D8] text-[#3D3B30]"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <DeleteConfirmButton onConfirm={() => handleDelete(c.id)} />
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-[#E9EDC9] rounded-2xl w-full max-w-lg p-6 space-y-4 shadow-2xl animate-in fade-in text-[#3D3B30]">
            <h3 className="text-base font-bold font-serif text-[#2D332D] border-b border-[#E9EDC9] pb-3">
              {editingId ? 'Modifica Candidato' : 'Nuovo Candidato Casting'}
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Ruolo Cercato</label>
                <input
                  type="text"
                  list="roles-list"
                  value={ruoloCercato}
                  onChange={(e) => setRuoloCercato(e.target.value)}
                  placeholder="Seleziona o digita un ruolo..."
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
                <datalist id="roles-list">
                  {roleSuggestions.map((r, i) => (
                    <option key={i} value={r} />
                  ))}
                </datalist>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[#6B705C] block mb-1 font-semibold">Candidato (Nome e Cognome)</label>
                  <input
                    type="text"
                    value={candidato}
                    onChange={(e) => setCandidato(e.target.value)}
                    placeholder="Nome attore/attrice"
                    className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                  />
                </div>

                <div>
                  <label className="text-[#6B705C] block mb-1 font-semibold">Stato</label>
                  <select
                    value={stato}
                    onChange={(e) => setStato(e.target.value as any)}
                    className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                  >
                    {CASTING_STATUSES.map((st) => (
                      <option key={st} value={st}>
                        {st}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[#6B705C] block mb-1 font-semibold">Voto (1-5 Stelle)</label>
                  <select
                    value={voto}
                    onChange={(e) => setVoto(Number(e.target.value))}
                    className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                  >
                    {[1, 2, 3, 4, 5].map((val) => (
                      <option key={val} value={val}>
                        {'★'.repeat(val)} ({val})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[#6B705C] block mb-1 font-semibold">Contatti (Telefono / Email)</label>
                  <input
                    type="text"
                    value={contatti}
                    onChange={(e) => setContatti(e.target.value)}
                    placeholder="+39..."
                    className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                  />
                </div>
              </div>

              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Link Drive / Showreel</label>
                <input
                  type="url"
                  value={linkDrive}
                  onChange={(e) => setLinkDrive(e.target.value)}
                  placeholder="https://..."
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
              </div>

              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Commento / Note Provino</label>
                <textarea
                  rows={2}
                  value={commento}
                  onChange={(e) => setCommento(e.target.value)}
                  placeholder="Note sulle doti espressive..."
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#E9EDC9]">
              <button
                onClick={() => setShowModal(false)}
                className="px-4 py-2 bg-[#E5E2D8] hover:bg-[#CCD5AE] text-[#3D3B30] rounded-xl text-xs font-semibold"
              >
                Annulla
              </button>
              <button
                onClick={handleSave}
                className="px-4 py-2 bg-[#D4A373] hover:bg-[#BC6C25] text-white rounded-xl text-xs font-bold"
              >
                Salva Candidato
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
