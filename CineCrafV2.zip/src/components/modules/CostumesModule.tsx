import React, { useState } from 'react';
import { Shirt, Plus, DollarSign, Edit3 } from 'lucide-react';
import { ProjectData, CostumeItem, CostumeStatus } from '../../types';
import { DeleteConfirmButton } from '../common/DeleteConfirmButton';
import { EmptyState } from '../common/EmptyState';

interface CostumesModuleProps {
  project: ProjectData;
  onUpdateProject: (updated: Partial<ProjectData>) => void;
}

const COSTUME_STATUSES: CostumeStatus[] = ['Da cercare', 'Da realizzare', 'Trovato'];

export const CostumesModule: React.FC<CostumesModuleProps> = ({ project, onUpdateProject }) => {
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const [capoAbbigliamento, setCapoAbbigliamento] = useState('');
  const [attore, setAttore] = useState('');
  const [stato, setStato] = useState<CostumeStatus>('Da cercare');
  const [scene, setScene] = useState('');
  const [costo, setCosto] = useState<number>(0);
  const [immagine, setImmagine] = useState('');

  // Autocomplete sources from Spoglio and Cast
  const costumeSuggestions = Array.from(
    new Set(project.scriptTags.filter((t) => t.categoria === 'Costumes').map((t) => t.testo))
  );

  const actorSuggestions = project.casting
    .filter((c) => c.stato === 'Confermato')
    .map((c) => c.candidato)
    .filter(Boolean);

  const handleOpenAdd = () => {
    setEditingId(null);
    setCapoAbbigliamento(costumeSuggestions[0] || '');
    setAttore(actorSuggestions[0] || '');
    setStato('Da cercare');
    setScene('1');
    setCosto(0);
    setImmagine('');
    setShowModal(true);
  };

  const handleOpenEdit = (c: CostumeItem) => {
    setEditingId(c.id);
    setCapoAbbigliamento(c.capoAbbigliamento);
    setAttore(c.attore);
    setStato(c.stato);
    setScene(c.scene);
    setCosto(c.costo);
    setImmagine(c.immagine || '');
    setShowModal(true);
  };

  const handleSave = () => {
    const itemData: CostumeItem = {
      id: editingId || 'cos_' + Date.now(),
      capoAbbigliamento,
      attore,
      stato,
      scene,
      costo: Number(costo),
      immagine,
    };

    let updatedList = [...project.costumi];
    if (editingId) {
      updatedList = updatedList.map((i) => (i.id === editingId ? itemData : i));
    } else {
      updatedList.unshift(itemData);
    }

    onUpdateProject({ costumi: updatedList });
    setShowModal(false);
  };

  const handleDelete = (id: string) => {
    const updated = project.costumi.filter((i) => i.id !== id);
    onUpdateProject({ costumi: updated });
  };

  const totalCost = project.costumi.reduce((acc, curr) => acc + (curr.costo || 0), 0);

  return (
    <div className="space-y-6 text-[#3D3B30]">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-[#E9EDC9] shadow-sm">
        <div>
          <h2 className="text-lg font-bold font-serif flex items-center gap-2 text-[#2D332D]">
            <Shirt className="w-5 h-5 text-[#BC6C25]" /> Modulo 05 — Costumi
          </h2>
          <p className="text-xs text-[#6B705C] mt-1">
            Gestisci la sartoria, l'acquisto e il noleggio dei capi d'abbigliamento per ogni attore. Totale stimato: €
            {totalCost.toLocaleString('it-IT')}
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-4 py-2.5 bg-[#D4A373] hover:bg-[#BC6C25] text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 shrink-0"
        >
          <Plus className="w-4 h-4" /> Aggiungi Costume
        </button>
      </div>

      {project.costumi.length === 0 ? (
        <EmptyState message="Nessun costume registrato. Aggiungi il primo capo di abbigliamento." onAction={handleOpenAdd} />
      ) : (
        <div className="bg-white rounded-2xl border border-[#E9EDC9] overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-[#3D3B30]">
              <thead className="bg-[#F2F0E9] text-[#6B705C] uppercase tracking-wider text-[10px] border-b border-[#E9EDC9]">
                <tr>
                  <th className="p-4 font-serif whitespace-nowrap">Capo d'Abbigliamento</th>
                  <th className="p-4 font-serif whitespace-nowrap">Attore / Personaggio</th>
                  <th className="p-4 font-serif whitespace-nowrap">Stato</th>
                  <th className="p-4 font-serif whitespace-nowrap">Scene</th>
                  <th className="p-4 font-serif whitespace-nowrap">Costo (€)</th>
                  <th className="p-4 text-right font-serif whitespace-nowrap">Azioni</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E9EDC9]">
                {project.costumi.map((item) => (
                  <tr key={item.id} className="hover:bg-[#F9F8F3] transition-colors">
                    <td className="p-4 font-bold text-[#2D332D] flex items-center gap-2 whitespace-nowrap">
                      {item.immagine && (
                        <img
                          src={item.immagine}
                          alt="preview"
                          className="w-8 h-8 rounded-lg object-cover border border-[#E9EDC9]"
                        />
                      )}
                      <span>{item.capoAbbigliamento}</span>
                    </td>
                    <td className="p-4 text-[#6B705C] whitespace-nowrap">{item.attore || '—'}</td>
                    <td className="p-4 whitespace-nowrap">
                      <span
                        className={`px-2.5 py-1 rounded-full text-[10px] font-bold inline-block whitespace-nowrap ${
                          item.stato === 'Trovato'
                            ? 'bg-[#A3B18A]/30 text-[#2D332D]'
                            : item.stato === 'Da realizzare'
                            ? 'bg-[#D4A373]/30 text-[#BC6C25]'
                            : 'bg-[#BC6C25]/20 text-[#BC6C25]'
                        }`}
                      >
                        {item.stato}
                      </span>
                    </td>
                    <td className="p-4 font-mono text-[#6B705C] whitespace-nowrap">Scena {item.scene || '1'}</td>
                    <td className="p-4 font-bold text-[#2D332D] whitespace-nowrap">€{item.costo || 0}</td>
                    <td className="p-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => handleOpenEdit(item)}
                          className="p-1.5 rounded-lg bg-[#F2F0E9] hover:bg-[#E5E2D8] text-[#3D3B30]"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <DeleteConfirmButton onConfirm={() => handleDelete(item.id)} />
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-[#E9EDC9] rounded-2xl w-full max-w-lg p-6 space-y-4 shadow-2xl animate-in fade-in text-[#3D3B30]">
            <h3 className="text-base font-bold font-serif text-[#2D332D] border-b border-[#E9EDC9] pb-3">
              {editingId ? 'Modifica Costume' : 'Nuovo Costume'}
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Capo di Abbigliamento</label>
                <input
                  type="text"
                  list="costumes-list"
                  value={capoAbbigliamento}
                  onChange={(e) => setCapoAbbigliamento(e.target.value)}
                  placeholder="Suggerito dallo spoglio..."
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
                <datalist id="costumes-list">
                  {costumeSuggestions.map((c, i) => (
                    <option key={i} value={c} />
                  ))}
                </datalist>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[#6B705C] block mb-1 font-semibold">Attore / Cast</label>
                  <input
                    type="text"
                    list="actors-list"
                    value={attore}
                    onChange={(e) => setAttore(e.target.value)}
                    placeholder="Nome attore..."
                    className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                  />
                  <datalist id="actors-list">
                    {actorSuggestions.map((a, i) => (
                      <option key={i} value={a} />
                    ))}
                  </datalist>
                </div>

                <div>
                  <label className="text-[#6B705C] block mb-1 font-semibold">Stato</label>
                  <select
                    value={stato}
                    onChange={(e) => setStato(e.target.value as any)}
                    className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                  >
                    {COSTUME_STATUSES.map((st) => (
                      <option key={st} value={st}>
                        {st}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[#6B705C] block mb-1 font-semibold">Scene</label>
                  <input
                    type="text"
                    value={scene}
                    onChange={(e) => setScene(e.target.value)}
                    placeholder="1, 2, 4"
                    className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                  />
                </div>

                <div>
                  <label className="text-[#6B705C] block mb-1 font-semibold">Costo (€)</label>
                  <input
                    type="number"
                    value={costo}
                    onChange={(e) => setCosto(Number(e.target.value))}
                    className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                  />
                </div>
              </div>

              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">URL Foto Costume (opzionale)</label>
                <input
                  type="url"
                  value={immagine}
                  onChange={(e) => setImmagine(e.target.value)}
                  placeholder="https://..."
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#E9EDC9]">
              <button onClick={() => setShowModal(false)} className="px-4 py-2 bg-[#E5E2D8] hover:bg-[#CCD5AE] text-[#3D3B30] rounded-xl text-xs font-semibold">
                Annulla
              </button>
              <button onClick={handleSave} className="px-4 py-2 bg-[#D4A373] hover:bg-[#BC6C25] text-white rounded-xl text-xs font-bold">
                Salva Costume
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
