import React, { useState, useEffect } from 'react';
import {
  FileText,
  Upload,
  Tag,
  Plus,
  Trash2,
  Sparkles,
  Search,
  Filter,
  CheckCircle2,
  Layers,
} from 'lucide-react';
import * as pdfjsLib from 'pdfjs-dist';
import { ProjectData, ScriptTag, TagCategory } from '../../types';
import { DeleteConfirmButton } from '../common/DeleteConfirmButton';
import { EmptyState } from '../common/EmptyState';

// Configure PDFJS worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

interface ScriptBreakdownModuleProps {
  project: ProjectData;
  onUpdateProject: (updated: Partial<ProjectData>) => void;
}

const CATEGORIES: TagCategory[] = [
  'Personaggio',
  'Extras',
  'Set Dressing',
  'Costumes',
  'Makeup',
  'Stunts',
  'Veicolo',
  'Special Effects',
  'Optical FX',
  'Mechanical FX',
  'Visual FX',
  'Livestock',
  'Animal Handler',
  'Music',
  'Sound',
  'Greenery',
  'Special Equipment',
  'Location',
];

export const ScriptBreakdownModule: React.FC<ScriptBreakdownModuleProps> = ({
  project,
  onUpdateProject,
}) => {
  const [scriptText, setScriptText] = useState(project.scriptText || '');
  const [pastedText, setPastedText] = useState('');
  const [selectedText, setSelectedText] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<TagCategory>('Personaggio');
  const [customCategoryInput, setCustomCategoryInput] = useState('');
  const [tagNote, setTagNote] = useState('');
  const [detectedSceneNumber, setDetectedSceneNumber] = useState('1');
  const [filterCategory, setFilterCategory] = useState<string>('Tutte');
  const [tagSearch, setTagSearch] = useState('');
  const [customCategories, setCustomCategories] = useState<string[]>([]);
  const [isProcessingPdf, setIsProcessingPdf] = useState(false);

  useEffect(() => {
    setScriptText(project.scriptText || '');
  }, [project.id]);

  // Extract Scene Headers automatically
  const detectSceneNumberForSelection = (selectionIndex: number) => {
    if (!scriptText) return '1';
    const textBefore = scriptText.slice(0, selectionIndex);
    // Regex matching scene headings like "1. INT. SALOTTO", "2. EXT. STRADA", "SCENA 3"
    const matches = Array.from(
      textBefore.matchAll(/(?:^|\n)\s*(\d+)[\.\s]+(?:INT|EXT|EST|INT\/EXT)\.?\s+([^\n]+)/gi)
    );
    if (matches.length > 0) {
      const lastMatch = matches[matches.length - 1];
      return lastMatch[1] || '1';
    }
    return '1';
  };

  // Text selection handler
  const handleTextSelect = () => {
    const selection = window.getSelection();
    if (selection && selection.toString().trim()) {
      const text = selection.toString().trim();
      setSelectedText(text);

      // Try detecting scene
      const anchorOffset = selection.anchorOffset;
      const scNo = detectSceneNumberForSelection(anchorOffset);
      setDetectedSceneNumber(scNo);
    }
  };

  // Handle PDF Upload using pdfjs-dist
  const handlePdfUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessingPdf(true);
    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      let fullText = '';

      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const textContent = await page.getTextContent();
        const pageItems = textContent.items as any[];
        let lastY = null;
        let pageText = '';

        for (const item of pageItems) {
          if (lastY !== null && Math.abs(item.transform[5] - lastY) > 5) {
            pageText += '\n';
          }
          pageText += item.str + ' ';
          lastY = item.transform[5];
        }
        fullText += pageText + '\n\n';
      }

      const updatedText = scriptText ? scriptText + '\n\n' + fullText : fullText;
      setScriptText(updatedText);
      onUpdateProject({ scriptText: updatedText });
    } catch (err) {
      console.error('Error parsing PDF:', err);
      alert('Errore nel caricamento del PDF. Puoi incollare il testo manualmente.');
    } finally {
      setIsProcessingPdf(false);
    }
  };

  // Add Tag
  const handleAddTag = () => {
    if (!selectedText.trim()) return;

    const categoryToUse =
      selectedCategory === 'Aggiungi Categoria Custom' && customCategoryInput.trim()
        ? customCategoryInput.trim()
        : selectedCategory;

    if (
      selectedCategory === 'Aggiungi Categoria Custom' &&
      customCategoryInput.trim() &&
      !customCategories.includes(customCategoryInput.trim())
    ) {
      setCustomCategories([...customCategories, customCategoryInput.trim()]);
    }

    const newTag: ScriptTag = {
      id: 'tag_' + Date.now(),
      testo: selectedText.trim(),
      categoria: categoryToUse,
      nota: tagNote.trim(),
      scenaNumero: detectedSceneNumber,
    };

    const updatedTags = [...project.scriptTags, newTag];
    onUpdateProject({ scriptTags: updatedTags });

    setSelectedText('');
    setTagNote('');
    setCustomCategoryInput('');
  };

  // Delete Tag
  const handleDeleteTag = (tagId: string) => {
    const updatedTags = project.scriptTags.filter((t) => t.id !== tagId);
    onUpdateProject({ scriptTags: updatedTags });
  };

  // Save manual pasted text
  const handleSavePastedText = () => {
    if (!pastedText.trim()) return;
    const updated = scriptText ? scriptText + '\n\n' + pastedText : pastedText;
    setScriptText(updated);
    onUpdateProject({ scriptText: updated });
    setPastedText('');
  };

  // Filtered Tags list
  const filteredTags = project.scriptTags.filter((t) => {
    const matchesCat = filterCategory === 'Tutte' || t.categoria === filterCategory;
    const matchesSearch =
      t.testo.toLowerCase().includes(tagSearch.toLowerCase()) ||
      (t.nota && t.nota.toLowerCase().includes(tagSearch.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  const allAvailableCategories = [...CATEGORIES, ...customCategories];

  return (
    <div className="space-y-6 text-[#3D3B30]">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-[#E9EDC9] shadow-sm">
        <div>
          <h2 className="text-lg font-bold font-serif flex items-center gap-2 text-[#2D332D]">
            <FileText className="w-5 h-5 text-[#BC6C25]" /> Spoglio della Sceneggiatura
          </h2>
          <p className="text-xs text-[#6B705C] mt-1">
            Seleziona il testo della sceneggiatura e categorizza gli elementi. Il numero di scena verrà rilevato automaticamente!
          </p>
        </div>

        {/* Upload Controls */}
        <div className="flex items-center gap-3">
          <label className="cursor-pointer px-4 py-2 bg-[#D4A373] hover:bg-[#BC6C25] text-white font-semibold text-xs rounded-xl shadow-xs transition-all flex items-center gap-2">
            <Upload className="w-4 h-4" />
            <span>{isProcessingPdf ? 'Elaborazione PDF...' : 'Carica PDF Sceneggiatura'}</span>
            <input
              type="file"
              accept=".pdf"
              onChange={handlePdfUpload}
              disabled={isProcessingPdf}
              className="hidden"
            />
          </label>
        </div>
      </div>

      {/* Main Split Layout: Script Reader on Left, Tagging Palette & Results on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Script Viewer */}
        <div className="lg:col-span-7 bg-white p-5 rounded-2xl border border-[#E9EDC9] shadow-sm flex flex-col space-y-4">
          <div className="flex items-center justify-between border-b border-[#E9EDC9] pb-3">
            <span className="text-xs font-bold uppercase text-[#6B705C] flex items-center gap-1.5 font-serif">
              <FileText className="w-4 h-4 text-[#BC6C25]" /> Testo Sceneggiatura (Seleziona per taggare)
            </span>
            <span className="text-[10px] bg-[#E9EDC9] px-2 py-0.5 rounded-full text-[#2D332D] font-bold">
              {scriptText ? `${scriptText.length} caratteri` : 'Vuoto'}
            </span>
          </div>

          {scriptText ? (
            <div
              onMouseUp={handleTextSelect}
              className="bg-[#F9F8F3] p-5 rounded-xl border border-[#CCD5AE] font-mono text-xs md:text-sm leading-relaxed text-[#3D3B30] overflow-y-auto max-h-[500px] whitespace-pre-wrap select-text cursor-text"
            >
              {scriptText}
            </div>
          ) : (
            <div className="space-y-4">
              <EmptyState message="Nessun testo ancora. Carica il PDF della sceneggiatura oppure incolla il testo qui sotto per iniziare a marcare personaggi, props e scene." />

              <div className="space-y-2">
                <label className="text-xs text-[#6B705C] font-semibold">Incolla Testo Manualmente</label>
                <textarea
                  rows={6}
                  value={pastedText}
                  onChange={(e) => setPastedText(e.target.value)}
                  placeholder="Incolla qui la tua sceneggiatura..."
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-3 text-xs text-[#3D3B30] placeholder-[#A3B18A] outline-none focus:border-[#D4A373]"
                />
                <button
                  onClick={handleSavePastedText}
                  className="px-4 py-2 bg-[#E5E2D8] hover:bg-[#CCD5AE] text-[#3D3B30] rounded-xl text-xs font-semibold transition-all"
                >
                  Salva Testo Incollato
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Active Tag Creator & Scene Elements List */}
        <div className="lg:col-span-5 space-y-6">
          {/* Tag Creator Card */}
          <div className="bg-white p-5 rounded-2xl border border-[#E9EDC9] shadow-sm space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#2D332D] flex items-center gap-2 font-serif">
              <Tag className="w-4 h-4 text-[#BC6C25]" /> Elemento Selezionato
            </h3>

            {selectedText ? (
              <div className="space-y-3 bg-[#F9F8F3] p-4 rounded-xl border border-[#D4A373]/40">
                <div>
                  <span className="text-[10px] text-[#6B705C] uppercase font-semibold">Testo Selezionato</span>
                  <p className="text-sm font-bold text-[#2D332D] bg-[#E9EDC9] p-2 rounded-lg mt-1 font-mono">
                    "{selectedText}"
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] text-[#6B705C] uppercase block mb-1 font-semibold">Categoria</label>
                    <select
                      value={selectedCategory}
                      onChange={(e) => setSelectedCategory(e.target.value as any)}
                      className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-lg p-2 text-xs text-[#3D3B30] outline-none focus:border-[#D4A373]"
                    >
                      {allAvailableCategories.map((cat) => (
                        <option key={cat} value={cat}>
                          {cat}
                        </option>
                      ))}
                      <option value="Aggiungi Categoria Custom">+ Categoria Custom...</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] text-[#6B705C] uppercase block mb-1 font-semibold">Scena Rilevata</label>
                    <input
                      type="text"
                      value={detectedSceneNumber}
                      onChange={(e) => setDetectedSceneNumber(e.target.value)}
                      className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-lg p-2 text-xs text-[#3D3B30] outline-none"
                    />
                  </div>
                </div>

                {selectedCategory === 'Aggiungi Categoria Custom' && (
                  <div>
                    <label className="text-[10px] text-[#6B705C] uppercase block mb-1 font-semibold">
                      Nome Categoria Personalizzata
                    </label>
                    <input
                      type="text"
                      value={customCategoryInput}
                      onChange={(e) => setCustomCategoryInput(e.target.value)}
                      placeholder="es. Effetti Pirotecnici"
                      className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-lg p-2 text-xs text-[#3D3B30] outline-none"
                    />
                  </div>
                )}

                <div>
                  <label className="text-[10px] text-[#6B705C] uppercase block mb-1 font-semibold">Nota Disambiguazione (opzionale)</label>
                  <input
                    type="text"
                    value={tagNote}
                    onChange={(e) => setTagNote(e.target.value)}
                    placeholder="es. Antico vintage, bagnato..."
                    className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-lg p-2 text-xs text-[#3D3B30] outline-none"
                  />
                </div>

                <button
                  onClick={handleAddTag}
                  className="w-full py-2.5 bg-[#D4A373] hover:bg-[#BC6C25] text-white text-xs font-bold rounded-xl shadow-xs transition-all flex items-center justify-center gap-1.5"
                >
                  <Plus className="w-4 h-4" /> Aggiungi Elemento allo Spoglio
                </button>
              </div>
            ) : (
              <p className="text-xs text-[#6B705C] italic p-3 bg-[#F2F0E9] rounded-xl border border-[#E9EDC9]">
                💡 Seleziona un testo nel riquadro a sinistra per sbloccare la categorizzazione.
              </p>
            )}
          </div>

          {/* Results List Grouped by Category */}
          <div className="bg-white p-5 rounded-2xl border border-[#E9EDC9] shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-[#E9EDC9] pb-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#2D332D] flex items-center gap-2 font-serif">
                <Layers className="w-4 h-4 text-[#BC6C25]" /> Elementi Tagghiati ({project.scriptTags.length})
              </h3>
            </div>

            {/* Filters */}
            <div className="grid grid-cols-2 gap-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-[#A3B18A] absolute left-2.5 top-2.5" />
                <input
                  type="text"
                  placeholder="Cerca tag..."
                  value={tagSearch}
                  onChange={(e) => setTagSearch(e.target.value)}
                  className="w-full bg-[#F2F0E9] pl-8 pr-2 py-1.5 text-xs text-[#3D3B30] rounded-lg border border-[#CCD5AE] outline-none"
                />
              </div>

              <select
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value)}
                className="bg-[#F2F0E9] px-2 py-1.5 text-xs text-[#3D3B30] rounded-lg border border-[#CCD5AE] outline-none"
              >
                <option value="Tutte">Tutte le Categorie</option>
                {allAvailableCategories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            {/* Tagged Items List */}
            <div className="space-y-2 max-h-[350px] overflow-y-auto pr-1">
              {filteredTags.length === 0 ? (
                <p className="text-xs text-[#6B705C] py-6 text-center">Nessun elemento trovato per questo filtro.</p>
              ) : (
                filteredTags.map((tag) => (
                  <div
                    key={tag.id}
                    className="p-3 bg-[#F9F8F3] hover:bg-[#F2F0E9] rounded-xl border border-[#E9EDC9] flex items-center justify-between text-xs transition-all"
                  >
                    <div className="space-y-1 max-w-[75%]">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-[#3D3B30]">{tag.testo}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#CCD5AE] text-[#2D332D] font-bold">
                          {tag.categoria}
                        </span>
                      </div>
                      <div className="text-[10px] text-[#6B705C] flex items-center gap-2">
                        <span>Scena #{tag.scenaNumero || '1'}</span>
                        {tag.nota && <span>• {tag.nota}</span>}
                      </div>
                    </div>

                    <DeleteConfirmButton onConfirm={() => handleDeleteTag(tag.id)} />
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
