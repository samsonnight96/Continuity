import React, { useState } from 'react';
import { MapPin, Plus, Edit3 } from 'lucide-react';
import { ProjectData, LocationItem, LocationStatus } from '../../types';
import { DeleteConfirmButton } from '../common/DeleteConfirmButton';
import { EmptyState } from '../common/EmptyState';

interface LocationModuleProps {
  project: ProjectData;
  onUpdateProject: (updated: Partial<ProjectData>) => void;
}

const LOCATION_STATUSES: LocationStatus[] = [
  'Da valutare',
  'Sopralluogo fatto',
  'Confermata',
  'Scartata',
];

export const LocationModule: React.FC<LocationModuleProps> = ({ project, onUpdateProject }) => {
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const [nome, setNome] = useState('');
  const [indirizzo, setIndirizzo] = useState('');
  const [stato, setStato] = useState<LocationStatus>('Da valutare');
  const [immagine, setImmagine] = useState('');

  // Autocomplete from Location tags in Spoglio
  const locationSuggestions = Array.from(
    new Set(project.scriptTags.filter((t) => t.categoria === 'Location').map((t) => t.testo))
  );

  const handleOpenAdd = () => {
    setEditingId(null);
    setNome(locationSuggestions[0] || '');
    setIndirizzo('');
    setStato('Da valutare');
    setImmagine('');
    setShowModal(true);
  };

  const handleOpenEdit = (l: LocationItem) => {
    setEditingId(l.id);
    setNome(l.nome);
    setIndirizzo(l.indirizzo);
    setStato(l.stato);
    setImmagine(l.immagine || '');
    setShowModal(true);
  };

  const handleSave = () => {
    const itemData: LocationItem = {
      id: editingId || 'loc_' + Date.now(),
      nome,
      indirizzo,
      stato,
      immagine,
    };

    let updatedList = [...project.location];
    if (editingId) {
      updatedList = updatedList.map((i) => (i.id === editingId ? itemData : i));
    } else {
      updatedList.unshift(itemData);
    }

    onUpdateProject({ location: updatedList });
    setShowModal(false);
  };

  const handleDelete = (id: string) => {
    const updated = project.location.filter((i) => i.id !== id);
    onUpdateProject({ location: updated });
  };

  return (
    <div className="space-y-6 text-[#3D3B30]">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-[#E9EDC9] shadow-sm">
        <div>
          <h2 className="text-lg font-bold font-serif flex items-center gap-2 text-[#2D332D]">
            <MapPin className="w-5 h-5 text-[#BC6C25]" /> Modulo 10 — Location & Sopralluoghi
          </h2>
          <p className="text-xs text-[#6B705C] mt-1">
            Gestisci i set e le ambientazioni per le riprese con stato dei sopralluoghi e foto di riferimento.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-4 py-2.5 bg-[#D4A373] hover:bg-[#BC6C25] text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 shrink-0"
        >
          <Plus className="w-4 h-4" /> Aggiungi Location
        </button>
      </div>

      {project.location.length === 0 ? (
        <EmptyState message="Nessuna location registrata. Aggiungi la prima ambientazione." onAction={handleOpenAdd} />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {project.location.map((loc) => (
            <div
              key={loc.id}
              className="bg-white rounded-2xl border border-[#E9EDC9] overflow-hidden shadow-xs flex flex-col justify-between group hover:border-[#CCD5AE] transition-all"
            >
              {loc.immagine ? (
                <div className="h-40 w-full overflow-hidden relative">
                  <img
                    src={loc.immagine}
                    alt={loc.nome}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <span
                    className={`absolute top-3 right-3 px-2.5 py-1 rounded-full text-[10px] font-bold shadow-xs ${
                      loc.stato === 'Confermata'
                        ? 'bg-[#A3B18A] text-[#2D332D]'
                        : loc.stato === 'Scartata'
                        ? 'bg-[#BC6C25] text-white'
                        : 'bg-[#D4A373] text-white'
                    }`}
                  >
                    {loc.stato}
                  </span>
                </div>
              ) : (
                <div className="h-32 bg-[#F2F0E9] flex items-center justify-center text-[#A3B18A] text-xs border-b border-[#E9EDC9]">
                  <MapPin className="w-6 h-6 text-[#A3B18A]" />
                </div>
              )}

              <div className="p-4 space-y-2">
                <h3 className="font-bold text-[#2D332D] text-sm font-serif">{loc.nome}</h3>
                <p className="text-xs text-[#6B705C] flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-[#BC6C25]" /> {loc.indirizzo || 'Indirizzo non specificato'}
                </p>
              </div>

              <div className="p-3 bg-[#F2F0E9] border-t border-[#E9EDC9] flex items-center justify-between">
                <button
                  onClick={() => handleOpenEdit(loc)}
                  className="px-2.5 py-1 bg-[#E5E2D8] hover:bg-[#CCD5AE] text-[#3D3B30] rounded-lg text-xs font-semibold flex items-center gap-1"
                >
                  <Edit3 className="w-3 h-3" /> Modifica
                </button>
                <DeleteConfirmButton onConfirm={() => handleDelete(loc.id)} />
              </div>
            </div>
          ))}
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-[#E9EDC9] rounded-2xl w-full max-w-lg p-6 space-y-4 shadow-2xl animate-in fade-in text-[#3D3B30]">
            <h3 className="text-base font-bold font-serif text-[#2D332D] border-b border-[#E9EDC9] pb-3">
              {editingId ? 'Modifica Location' : 'Nuova Location'}
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Nome Location</label>
                <input
                  type="text"
                  list="locs-list"
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  placeholder="Nome del set/location..."
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
                <datalist id="locs-list">
                  {locationSuggestions.map((l, i) => (
                    <option key={i} value={l} />
                  ))}
                </datalist>
              </div>

              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Indirizzo / Citta</label>
                <input
                  type="text"
                  value={indirizzo}
                  onChange={(e) => setIndirizzo(e.target.value)}
                  placeholder="Via Grazioli 14, Frascati..."
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
              </div>

              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Stato</label>
                <select
                  value={stato}
                  onChange={(e) => setStato(e.target.value as any)}
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                >
                  {LOCATION_STATUSES.map((st) => (
                    <option key={st} value={st}>
                      {st}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">URL Immagine Sopralluogo</label>
                <input
                  type="url"
                  value={immagine}
                  onChange={(e) => setImmagine(e.target.value)}
                  placeholder="https://..."
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#E9EDC9]">
              <button onClick={() => setShowModal(false)} className="px-4 py-2 bg-[#E5E2D8] hover:bg-[#CCD5AE] text-[#3D3B30] rounded-xl text-xs font-semibold">
                Annulla
              </button>
              <button onClick={handleSave} className="px-4 py-2 bg-[#D4A373] hover:bg-[#BC6C25] text-white rounded-xl text-xs font-bold">
                Salva Location
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
