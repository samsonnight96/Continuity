import React, { useState } from 'react';
import { Camera, Plus, Film, Clock, Image as ImageIcon, Layers, Edit3 } from 'lucide-react';
import { ProjectData, ShotItem, ShotType, ShotAngle, ShotMovement } from '../../types';
import { DeleteConfirmButton } from '../common/DeleteConfirmButton';
import { EmptyState } from '../common/EmptyState';

interface ShotListModuleProps {
  project: ProjectData;
  onUpdateProject: (updated: Partial<ProjectData>) => void;
}

const SHOT_TYPES: ShotType[] = [
  'Close-up',
  'Medium Close-up',
  'Extreme Close-up',
  'Wide Close-up',
  'Medium Shot',
  'Close Shot',
  'Medium Close Shot',
  'Wide Shot',
  'Extreme Wide Shot',
  'Full Shot',
  'Medium Full Shot',
  'Long Shot',
  'Extreme Long Shot',
];

const SHOT_ANGLES: ShotAngle[] = [
  'Camera Height',
  'Eye Level',
  'Low Angle',
  'High Angle',
  'Overhead',
  'Shoulder Level',
  'Hip Level',
  'Knee Level',
  'Ground Level',
  'Dutch Angle',
  'Dutch (left)',
  'Dutch (right)',
  'Framing',
  'Single/Two Shot',
  'Three Shot',
  'Over-the-Shoulder',
  'Over-the-Hip',
  'Rack Focus',
  'Shallow Focus',
  'Deep Focus',
  'Tilt-Shift',
  'Zoom',
];

const SHOT_MOVEMENTS: ShotMovement[] = ['Static', 'Pan', 'Tilt', 'Swish Pan', 'Swish Tilt', 'Tracking'];

export const ShotListModule: React.FC<ShotListModuleProps> = ({ project, onUpdateProject }) => {
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form state
  const [scena, setScena] = useState('1');
  const [numeroInquadratura, setNumeroInquadratura] = useState<number>(1);
  const [tipo, setTipo] = useState<ShotType>('Medium Shot');
  const [angolo, setAngolo] = useState<ShotAngle>('Eye Level');
  const [movimento, setMovimento] = useState<ShotMovement>('Static');
  const [descrizione, setDescrizione] = useState('');
  const [time, setTime] = useState('00:30');
  const [immagine, setImmagine] = useState('');
  const [equipaggiamento, setEquipaggiamento] = useState('');
  const [lens, setLens] = useState('');
  const [frameRate, setFrameRate] = useState<number>(24);
  const [vfx, setVfx] = useState('');
  const [sound, setSound] = useState('');
  const [lighting, setLighting] = useState('');
  const [location, setLocation] = useState('');
  const [notes, setNotes] = useState('');

  // Extract Scene number suggestions from Spoglio
  const sceneSuggestions = Array.from(
    new Set(project.scriptTags.map((t) => t.scenaNumero || '1').filter(Boolean))
  ).sort((a, b) => Number(a) - Number(b));

  const handleOpenAddModal = (scenaNo = '1') => {
    setEditingId(null);
    setScena(scenaNo);

    const shotsForScene = project.shotList.filter((s) => s.scena === scenaNo);
    setNumeroInquadratura(shotsForScene.length + 1);

    setTipo('Medium Shot');
    setAngolo('Eye Level');
    setMovimento('Static');
    setDescrizione('');
    setTime('00:30');
    setImmagine('');
    setEquipaggiamento('');
    setLens('');
    setFrameRate(24);
    setVfx('');
    setSound('');
    setLighting('');
    setLocation('');
    setNotes('');
    setShowModal(true);
  };

  const handleOpenEditModal = (s: ShotItem) => {
    setEditingId(s.id);
    setScena(s.scena);
    setNumeroInquadratura(s.numeroInquadratura);
    setTipo(s.tipo);
    setAngolo(s.angolo);
    setMovimento(s.movimento);
    setDescrizione(s.descrizione);
    setTime(s.time);
    setImmagine(s.immagine || '');
    setEquipaggiamento(s.equipaggiamento || '');
    setLens(s.lens || '');
    setFrameRate(s.frameRate || 24);
    setVfx(s.vfx || '');
    setSound(s.sound || '');
    setLighting(s.lighting || '');
    setLocation(s.location || '');
    setNotes(s.notes || '');
    setShowModal(true);
  };

  const handleSave = () => {
    const shotData: ShotItem = {
      id: editingId || 'shot_' + Date.now(),
      scena,
      numeroInquadratura: Number(numeroInquadratura),
      tipo,
      angolo,
      movimento,
      descrizione,
      time,
      immagine,
      equipaggiamento,
      lens,
      frameRate: Number(frameRate),
      vfx,
      sound,
      lighting,
      location,
      notes,
    };

    let updatedList = [...project.shotList];
    if (editingId) {
      updatedList = updatedList.map((item) => (item.id === editingId ? shotData : item));
    } else {
      updatedList.push(shotData);
    }

    onUpdateProject({ shotList: updatedList });
    setShowModal(false);
  };

  const handleDelete = (id: string) => {
    const updated = project.shotList.filter((s) => s.id !== id);
    onUpdateProject({ shotList: updated });
  };

  // Group shots by Scene Number
  const scenesGrouped: Record<string, ShotItem[]> = {};
  project.shotList.forEach((shot) => {
    const sc = shot.scena || '1';
    if (!scenesGrouped[sc]) scenesGrouped[sc] = [];
    scenesGrouped[sc].push(shot);
  });

  const sortedSceneKeys = Object.keys(scenesGrouped).sort((a, b) => Number(a) - Number(b));

  return (
    <div className="space-y-6 text-[#3D3B30]">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-[#E9EDC9] shadow-sm">
        <div>
          <h2 className="text-lg font-bold font-serif flex items-center gap-2 text-[#2D332D]">
            <Camera className="w-5 h-5 text-[#BC6C25]" /> Modulo 04 — Shot List (Lista Inquadrature)
          </h2>
          <p className="text-xs text-[#6B705C] mt-1">
            Organizza le inquadrature per scena con opzioni di angolazione, tipo, movimento, lenti e storyboard visuale.
          </p>
        </div>

        <button
          onClick={() => handleOpenAddModal('1')}
          className="px-4 py-2.5 bg-[#D4A373] hover:bg-[#BC6C25] text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 shrink-0"
        >
          <Plus className="w-4 h-4" /> Nuova Inquadratura
        </button>
      </div>

      {project.shotList.length === 0 ? (
        <EmptyState
          message="Nessuna inquadratura nella shot list. Crea la tua prima inquadratura per iniziare lo storyboard di produzione."
          onAction={() => handleOpenAddModal('1')}
        />
      ) : (
        <div className="space-y-6">
          {sortedSceneKeys.map((scKey) => {
            const shots = scenesGrouped[scKey];
            return (
              <div key={scKey} className="bg-white p-5 rounded-2xl border border-[#E9EDC9] space-y-4 shadow-sm">
                {/* Scene Header */}
                <div className="flex items-center justify-between border-b border-[#E9EDC9] pb-3">
                  <div className="flex items-center gap-3">
                    <span className="w-9 h-9 rounded-xl bg-[#BC6C25] text-white font-black text-sm flex items-center justify-center shadow-xs">
                      #{scKey}
                    </span>
                    <div>
                      <h3 className="text-sm font-bold text-[#2D332D] uppercase tracking-wider font-serif">
                        SCENA {scKey} — {shots[0]?.location || 'LOCATION GENERICA'}
                      </h3>
                      <p className="text-[11px] text-[#6B705C]">
                        {shots.length} inquadratura/e totali
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => handleOpenAddModal(scKey)}
                    className="px-3 py-1.5 bg-[#E5E2D8] hover:bg-[#CCD5AE] text-[#3D3B30] text-xs font-semibold rounded-xl transition-all flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" /> + Inquadratura in Scena {scKey}
                  </button>
                </div>

                {/* Horizontal Grid of Shot Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {shots.map((sh) => (
                    <div
                      key={sh.id}
                      className="bg-[#F9F8F3] p-4 rounded-xl border border-[#E9EDC9] space-y-3 flex flex-col justify-between hover:border-[#CCD5AE] transition-all shadow-xs group"
                    >
                      {/* Card Header */}
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-[#2D332D] bg-[#E9EDC9] px-2.5 py-1 rounded-md">
                          Inq. #{sh.numeroInquadratura}
                        </span>
                        <div className="flex items-center gap-1 text-[10px] text-[#6B705C] bg-[#F2F0E9] px-2 py-0.5 rounded-full font-semibold">
                          <Clock className="w-3 h-3 text-[#BC6C25]" /> {sh.time}
                        </div>
                      </div>

                      {/* Image Thumbnail if available */}
                      {sh.immagine ? (
                        <div className="h-32 w-full rounded-lg overflow-hidden border border-[#E9EDC9]">
                          <img
                            src={sh.immagine}
                            alt="Storyboard preview"
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                        </div>
                      ) : (
                        <div className="h-24 w-full rounded-lg bg-[#F2F0E9] border border-dashed border-[#CCD5AE] flex items-center justify-center text-[#A3B18A] text-xs gap-1">
                          <ImageIcon className="w-4 h-4" /> Nessuna immagine
                        </div>
                      )}

                      {/* Shot Details */}
                      <div className="space-y-1 text-xs">
                        <div className="flex flex-wrap gap-1">
                          <span className="px-2 py-0.5 rounded bg-[#E9EDC9] text-[#2D332D] text-[10px] font-bold">
                            {sh.tipo}
                          </span>
                          <span className="px-2 py-0.5 rounded bg-[#F2F0E9] text-[#3D3B30] text-[10px]">
                            {sh.angolo}
                          </span>
                          <span className="px-2 py-0.5 rounded bg-[#F2F0E9] text-[#3D3B30] text-[10px]">
                            {sh.movimento}
                          </span>
                        </div>

                        {sh.descrizione && (
                          <p className="text-[#3D3B30] text-xs italic line-clamp-2 mt-1">
                            "{sh.descrizione}"
                          </p>
                        )}

                        <div className="text-[10px] text-[#6B705C] space-y-0.5 pt-1 border-t border-[#E9EDC9]">
                          {sh.equipaggiamento && <div>📷 Camera: {sh.equipaggiamento}</div>}
                          {sh.lens && <div>🔍 Lens: {sh.lens}</div>}
                        </div>
                      </div>

                      {/* Action Footer */}
                      <div className="flex items-center justify-between pt-2 border-t border-[#E9EDC9]">
                        <button
                          onClick={() => handleOpenEditModal(sh)}
                          className="px-2.5 py-1 bg-[#F2F0E9] hover:bg-[#E5E2D8] text-[#3D3B30] rounded-lg text-xs font-semibold flex items-center gap-1"
                        >
                          <Edit3 className="w-3 h-3" /> Modifica
                        </button>
                        <DeleteConfirmButton onConfirm={() => handleDelete(sh.id)} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Shot Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white border border-[#E9EDC9] rounded-2xl w-full max-w-2xl p-6 space-y-4 shadow-2xl animate-in fade-in my-8 text-[#3D3B30]">
            <h3 className="text-base font-bold font-serif text-[#2D332D] border-b border-[#E9EDC9] pb-3">
              {editingId ? 'Modifica Inquadratura' : 'Nuova Inquadratura'}
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Scena *</label>
                <input
                  type="text"
                  value={scena}
                  onChange={(e) => setScena(e.target.value)}
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
              </div>

              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">N. Inquadratura *</label>
                <input
                  type="number"
                  value={numeroInquadratura}
                  onChange={(e) => setNumeroInquadratura(Number(e.target.value))}
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
              </div>

              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Durata / Time *</label>
                <input
                  type="text"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  placeholder="00:30"
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Tipo *</label>
                <select
                  value={tipo}
                  onChange={(e) => setTipo(e.target.value as any)}
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                >
                  {SHOT_TYPES.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Angolo *</label>
                <select
                  value={angolo}
                  onChange={(e) => setAngolo(e.target.value as any)}
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                >
                  {SHOT_ANGLES.map((a) => (
                    <option key={a} value={a}>
                      {a}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Movimento *</label>
                <select
                  value={movimento}
                  onChange={(e) => setMovimento(e.target.value as any)}
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                >
                  {SHOT_MOVEMENTS.map((m) => (
                    <option key={m} value={m}>
                      {m}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="text-xs">
              <label className="text-[#6B705C] block mb-1 font-semibold">Descrizione Azione</label>
              <textarea
                rows={2}
                value={descrizione}
                onChange={(e) => setDescrizione(e.target.value)}
                placeholder="Descrivi l'azione della macchina da presa o degli attori..."
                className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">URL Immagine / Storyboard</label>
                <input
                  type="url"
                  value={immagine}
                  onChange={(e) => setImmagine(e.target.value)}
                  placeholder="https://..."
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
              </div>

              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Camera / Equipaggiamento</label>
                <input
                  type="text"
                  value={equipaggiamento}
                  onChange={(e) => setEquipaggiamento(e.target.value)}
                  placeholder="ARRI Alexa, Steadicam..."
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Lens (Obiettivo)</label>
                <input
                  type="text"
                  value={lens}
                  onChange={(e) => setLens(e.target.value)}
                  placeholder="35mm anamorfico"
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
              </div>

              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Frame Rate (fps)</label>
                <input
                  type="number"
                  value={frameRate}
                  onChange={(e) => setFrameRate(Number(e.target.value))}
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
              </div>

              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Location</label>
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="Salotto Villa Grazioli"
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#E9EDC9]">
              <button
                onClick={() => setShowModal(false)}
                className="px-4 py-2 bg-[#E5E2D8] hover:bg-[#CCD5AE] text-[#3D3B30] rounded-xl text-xs font-semibold"
              >
                Annulla
              </button>
              <button
                onClick={handleSave}
                className="px-4 py-2 bg-[#D4A373] hover:bg-[#BC6C25] text-white rounded-xl text-xs font-bold"
              >
                Salva Inquadratura
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
