import React, { useState } from 'react';
import { Users, Plus, Filter, Phone, Edit3 } from 'lucide-react';
import { ProjectData, TroupeMember, TroupeDepartment, CustomRole } from '../../types';
import { DeleteConfirmButton } from '../common/DeleteConfirmButton';
import { EmptyState } from '../common/EmptyState';

interface TroupeModuleProps {
  project: ProjectData;
  customRoles: CustomRole[];
  onAddCustomRole: (reparto: TroupeDepartment, ruolo: string) => void;
  onUpdateProject: (updated: Partial<ProjectData>) => void;
}

const PREDEFINED_ROLES: Record<TroupeDepartment, string[]> = {
  Regia: [
    'Regista',
    'Aiuto regista',
    'Segretario di edizione',
    'Primo assistente alla regia',
    'Secondo assistente alla regia',
  ],
  Fotografia: [
    'DOP',
    'Primo operatore',
    'Assistente operatore',
    'Focus puller',
    'Aiuto operatore',
    'Macchinista',
    'Capo elettricista',
    'Primo elettricista',
  ],
  Produzione: [
    'Produttore',
    'Produttore esecutivo',
    'Direttore di produzione',
    'Organizzatore di produzione',
    'Assistente di produzione',
    'Location manager',
    'Scenografo',
    'Trucco e parrucco',
  ],
};

export const TroupeModule: React.FC<TroupeModuleProps> = ({
  project,
  customRoles,
  onAddCustomRole,
  onUpdateProject,
}) => {
  const [filterDept, setFilterDept] = useState<string>('Tutti');
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const [reparto, setReparto] = useState<TroupeDepartment>('Regia');
  const [ruolo, setRuolo] = useState<string>('Regista');
  const [customRoleInput, setCustomRoleInput] = useState<string>('');
  const [isCustomRole, setIsCustomRole] = useState(false);
  const [nome, setNome] = useState('');
  const [contatto, setContatto] = useState('');
  const [stato, setStato] = useState<'Da confermare' | 'Confermato'>('Da confermare');
  const [note, setNote] = useState('');

  const handleOpenAdd = () => {
    setEditingId(null);
    setReparto('Regia');
    setRuolo(PREDEFINED_ROLES['Regia'][0]);
    setIsCustomRole(false);
    setCustomRoleInput('');
    setNome('');
    setContatto('');
    setStato('Da confermare');
    setNote('');
    setShowModal(true);
  };

  const handleOpenEdit = (m: TroupeMember) => {
    setEditingId(m.id);
    setReparto(m.reparto);
    setRuolo(m.ruolo);
    setIsCustomRole(false);
    setNome(m.nome);
    setContatto(m.contatto);
    setStato(m.stato);
    setNote(m.note || '');
    setShowModal(true);
  };

  const handleSave = () => {
    let finalRole = ruolo;
    if (isCustomRole && customRoleInput.trim()) {
      finalRole = customRoleInput.trim();
      onAddCustomRole(reparto, finalRole);
    }

    const memberData: TroupeMember = {
      id: editingId || 'trp_' + Date.now(),
      reparto,
      ruolo: finalRole,
      nome,
      contatto,
      stato,
      note,
    };

    let updatedList = [...project.troupe];
    if (editingId) {
      updatedList = updatedList.map((i) => (i.id === editingId ? memberData : i));
    } else {
      updatedList.unshift(memberData);
    }

    onUpdateProject({ troupe: updatedList });
    setShowModal(false);
  };

  const handleDelete = (id: string) => {
    const updated = project.troupe.filter((i) => i.id !== id);
    onUpdateProject({ troupe: updated });
  };

  // Get all available roles for selected department (predefined + custom)
  const getRolesForDepartment = (dept: TroupeDepartment) => {
    const predefined = PREDEFINED_ROLES[dept] || [];
    const customForDept = customRoles.filter((cr) => cr.reparto === dept).map((cr) => cr.ruolo);
    return Array.from(new Set([...predefined, ...customForDept]));
  };

  const filteredMembers = project.troupe.filter(
    (m) => filterDept === 'Tutti' || m.reparto === filterDept
  );

  return (
    <div className="space-y-6 text-[#3D3B30]">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-[#E9EDC9] shadow-sm">
        <div>
          <h2 className="text-lg font-bold font-serif flex items-center gap-2 text-[#2D332D]">
            <Users className="w-5 h-5 text-[#BC6C25]" /> Modulo 07 — Troupe (Crew)
          </h2>
          <p className="text-xs text-[#6B705C] mt-1">
            Gestisci la composizione dei reparti di regia, fotografia e produzione con ruoli predefiniti e personalizzabili.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-4 py-2.5 bg-[#D4A373] hover:bg-[#BC6C25] text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 shrink-0"
        >
          <Plus className="w-4 h-4" /> Aggiungi Membro Troupe
        </button>
      </div>

      {/* Department Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {['Tutti', 'Regia', 'Fotografia', 'Produzione'].map((dept) => {
          const count =
            dept === 'Tutti'
              ? project.troupe.length
              : project.troupe.filter((m) => m.reparto === dept).length;
          return (
            <button
              key={dept}
              onClick={() => setFilterDept(dept)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all flex items-center gap-2 shrink-0 ${
                filterDept === dept
                  ? 'bg-[#D4A373] text-white shadow-xs'
                  : 'bg-[#E5E2D8] text-[#3D3B30] hover:bg-[#CCD5AE]'
              }`}
            >
              <span>{dept}</span>
              <span className="text-[10px] px-2 py-0.2 rounded-full bg-black/10">{count}</span>
            </button>
          );
        })}
      </div>

      {filteredMembers.length === 0 ? (
        <EmptyState message="Nessun membro della troupe registrato per questo filtro." onAction={handleOpenAdd} />
      ) : (
        <div className="bg-white rounded-2xl border border-[#E9EDC9] overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-[#3D3B30]">
              <thead className="bg-[#F2F0E9] text-[#6B705C] uppercase tracking-wider text-[10px] border-b border-[#E9EDC9]">
                <tr>
                  <th className="p-4 font-serif whitespace-nowrap">Reparto</th>
                  <th className="p-4 font-serif whitespace-nowrap">Ruolo</th>
                  <th className="p-4 font-serif whitespace-nowrap">Nome e Cognome</th>
                  <th className="p-4 font-serif whitespace-nowrap">Contatto</th>
                  <th className="p-4 font-serif whitespace-nowrap">Stato</th>
                  <th className="p-4 font-serif whitespace-nowrap">Note</th>
                  <th className="p-4 text-right font-serif whitespace-nowrap">Azioni</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E9EDC9]">
                {filteredMembers.map((m) => (
                  <tr key={m.id} className="hover:bg-[#F9F8F3] transition-colors">
                    <td className="p-4 font-bold text-[#BC6C25] whitespace-nowrap">{m.reparto}</td>
                    <td className="p-4 font-bold text-[#2D332D] whitespace-nowrap">{m.ruolo}</td>
                    <td className="p-4 text-[#2D332D] font-medium whitespace-nowrap">{m.nome || '—'}</td>
                    <td className="p-4 text-[#6B705C] whitespace-nowrap">
                      {m.contatto ? (
                        <span className="flex items-center gap-1">
                          <Phone className="w-3 h-3 text-[#A3B18A]" /> {m.contatto}
                        </span>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td className="p-4 whitespace-nowrap">
                      <span
                        className={`px-2.5 py-1 rounded-full text-[10px] font-bold inline-block whitespace-nowrap ${
                          m.stato === 'Confermato'
                            ? 'bg-[#A3B18A]/30 text-[#2D332D]'
                            : 'bg-[#D4A373]/30 text-[#BC6C25]'
                        }`}
                      >
                        {m.stato}
                      </span>
                    </td>
                    <td className="p-4 text-[#6B705C]">{m.note || '—'}</td>
                    <td className="p-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => handleOpenEdit(m)}
                          className="p-1.5 rounded-lg bg-[#F2F0E9] hover:bg-[#E5E2D8] text-[#3D3B30]"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <DeleteConfirmButton onConfirm={() => handleDelete(m.id)} />
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-[#E9EDC9] rounded-2xl w-full max-w-lg p-6 space-y-4 shadow-2xl animate-in fade-in text-[#3D3B30]">
            <h3 className="text-base font-bold font-serif text-[#2D332D] border-b border-[#E9EDC9] pb-3">
              {editingId ? 'Modifica Membro Troupe' : 'Nuovo Membro Troupe'}
            </h3>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[#6B705C] block mb-1 font-semibold">Reparto *</label>
                  <select
                    value={reparto}
                    onChange={(e) => {
                      const newDept = e.target.value as TroupeDepartment;
                      setReparto(newDept);
                      const roles = getRolesForDepartment(newDept);
                      setRuolo(roles[0] || '');
                    }}
                    className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                  >
                    <option value="Regia">Regia</option>
                    <option value="Fotografia">Fotografia</option>
                    <option value="Produzione">Produzione</option>
                  </select>
                </div>

                <div>
                  <label className="text-[#6B705C] block mb-1 font-semibold">Ruolo *</label>
                  {!isCustomRole ? (
                    <select
                      value={ruolo}
                      onChange={(e) => {
                        if (e.target.value === 'CUSTOM_NEW') {
                          setIsCustomRole(true);
                        } else {
                          setRuolo(e.target.value);
                        }
                      }}
                      className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                    >
                      {getRolesForDepartment(reparto).map((r) => (
                        <option key={r} value={r}>
                          {r}
                        </option>
                      ))}
                      <option value="CUSTOM_NEW">+ Aggiungi nuovo ruolo...</option>
                    </select>
                  ) : (
                    <input
                      type="text"
                      value={customRoleInput}
                      onChange={(e) => setCustomRoleInput(e.target.value)}
                      placeholder="es. Drone Operator"
                      className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                    />
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[#6B705C] block mb-1 font-semibold">Nome e Cognome *</label>
                  <input
                    type="text"
                    value={nome}
                    onChange={(e) => setNome(e.target.value)}
                    placeholder="Nome professionista..."
                    className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                  />
                </div>

                <div>
                  <label className="text-[#6B705C] block mb-1 font-semibold">Stato *</label>
                  <select
                    value={stato}
                    onChange={(e) => setStato(e.target.value as any)}
                    className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                  >
                    <option value="Da confermare">Da confermare</option>
                    <option value="Confermato">Confermato</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Contatto (Telefono / Email)</label>
                <input
                  type="text"
                  value={contatto}
                  onChange={(e) => setContatto(e.target.value)}
                  placeholder="+39..."
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
              </div>

              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Note</label>
                <textarea
                  rows={2}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Diaria, disponibilità date..."
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#E9EDC9]">
              <button onClick={() => setShowModal(false)} className="px-4 py-2 bg-[#E5E2D8] hover:bg-[#CCD5AE] text-[#3D3B30] rounded-xl text-xs font-semibold">
                Annulla
              </button>
              <button onClick={handleSave} className="px-4 py-2 bg-[#D4A373] hover:bg-[#BC6C25] text-white rounded-xl text-xs font-bold">
                Salva Membro
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
