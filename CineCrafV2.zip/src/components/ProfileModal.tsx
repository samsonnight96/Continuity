import React, { useState } from 'react';
import { User, Mail, Calendar, Settings, Plus, Trash2, X } from 'lucide-react';
import { UserProfile, CustomRole, TroupeDepartment } from '../types';

interface ProfileModalProps {
  user: UserProfile;
  customRoles: CustomRole[];
  onUpdateUser: (data: Partial<UserProfile>) => void;
  onAddCustomRole: (reparto: TroupeDepartment, ruolo: string) => void;
  onClose: () => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  user,
  customRoles,
  onUpdateUser,
  onAddCustomRole,
  onClose,
}) => {
  const [nome, setNome] = useState(user.nome);
  const [cognome, setCognome] = useState(user.cognome);
  const [email, setEmail] = useState(user.email);
  const [dataNascita, setDataNascita] = useState(user.dataNascita);

  const [newRoleDept, setNewRoleDept] = useState<TroupeDepartment>('Regia');
  const [newRoleInput, setNewRoleInput] = useState('');

  const handleSaveProfile = () => {
    onUpdateUser({ nome, cognome, email, dataNascita });
  };

  const handleAddRole = () => {
    if (!newRoleInput.trim()) return;
    onAddCustomRole(newRoleDept, newRoleInput.trim());
    setNewRoleInput('');
  };

  return (
    <div className="p-4 md:p-6 text-[#3D3B30] space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between bg-white p-5 rounded-2xl border border-[#E9EDC9] shadow-sm">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-full bg-[#D4A373] text-white font-black text-xl flex items-center justify-center shadow-xs">
            {nome.charAt(0)}
            {cognome.charAt(0)}
          </div>
          <div>
            <h2 className="text-xl font-bold font-serif text-[#2D332D]">
              {nome} {cognome}
            </h2>
            <p className="text-xs text-[#6B705C]">{email} • Filmmaker / Regista</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* User Details Form */}
        <div className="bg-white p-6 rounded-2xl border border-[#E9EDC9] shadow-sm space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#2D332D] border-b border-[#E9EDC9] pb-3 flex items-center gap-2 font-serif">
            <User className="w-4 h-4 text-[#BC6C25]" /> Dati Personali
          </h3>

          <div className="space-y-3 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Nome *</label>
                <input
                  type="text"
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
              </div>

              <div>
                <label className="text-[#6B705C] block mb-1 font-semibold">Cognome *</label>
                <input
                  type="text"
                  value={cognome}
                  onChange={(e) => setCognome(e.target.value)}
                  className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
                />
              </div>
            </div>

            <div>
              <label className="text-[#6B705C] block mb-1 font-semibold">Email *</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
              />
            </div>

            <div>
              <label className="text-[#6B705C] block mb-1 font-semibold">Data di Nascita *</label>
              <input
                type="date"
                value={dataNascita}
                onChange={(e) => setDataNascita(e.target.value)}
                className="w-full bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl p-2.5 text-[#3D3B30] outline-none focus:border-[#D4A373]"
              />
            </div>

            <button
              onClick={handleSaveProfile}
              className="w-full py-2.5 bg-[#D4A373] hover:bg-[#BC6C25] text-white text-xs font-bold rounded-xl shadow-xs transition-all"
            >
              Salva Profilo
            </button>
          </div>
        </div>

        {/* Global Custom Troupe Roles Manager */}
        <div className="bg-white p-6 rounded-2xl border border-[#E9EDC9] shadow-sm space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#2D332D] border-b border-[#E9EDC9] pb-3 flex items-center gap-2 font-serif">
            <Settings className="w-4 h-4 text-[#BC6C25]" /> Ruoli Custom Troupe (Globali)
          </h3>

          <p className="text-xs text-[#6B705C]">
            I ruoli aggiunti qui saranno salvati a livello di account e disponibili in tutti i tuoi progetti futuri.
          </p>

          <div className="flex gap-2 text-xs">
            <select
              value={newRoleDept}
              onChange={(e) => setNewRoleDept(e.target.value as TroupeDepartment)}
              className="bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl px-2.5 py-2 text-[#3D3B30] outline-none focus:border-[#D4A373]"
            >
              <option value="Regia">Regia</option>
              <option value="Fotografia">Fotografia</option>
              <option value="Produzione">Produzione</option>
            </select>

            <input
              type="text"
              value={newRoleInput}
              onChange={(e) => setNewRoleInput(e.target.value)}
              placeholder="es. Dialogue Coach"
              className="flex-1 bg-[#F2F0E9] border border-[#CCD5AE] rounded-xl px-3 py-2 text-[#3D3B30] outline-none focus:border-[#D4A373]"
            />

            <button
              onClick={handleAddRole}
              className="px-3 py-2 bg-[#E5E2D8] hover:bg-[#CCD5AE] text-[#3D3B30] rounded-xl font-semibold shrink-0"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-2 max-h-48 overflow-y-auto">
            {customRoles.map((cr) => (
              <div
                key={cr.id}
                className="p-2.5 bg-[#F9F8F3] rounded-xl border border-[#E9EDC9] flex items-center justify-between text-xs"
              >
                <span className="font-bold text-[#3D3B30]">{cr.ruolo}</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#CCD5AE] text-[#2D332D] font-bold">
                  {cr.reparto}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
