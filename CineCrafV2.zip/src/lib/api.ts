import {
  ProjectData,
  CalendarEvent,
  UserProfile,
  CustomRole,
} from '../types';

// API client helper for backend communication with localStorage offline fallback
const BASE_URL = '/api';

export async function fetchProjects(): Promise<{ id: string; titolo: string; tipo: any; updatedAt: string }[]> {
  try {
    const res = await fetch(`${BASE_URL}/projects`);
    if (res.ok) {
      return await res.json();
    }
  } catch (e) {
    console.warn('API fetchProjects fallback to local:', e);
  }
  const local = localStorage.getItem('scenecraft_projects_list');
  return local ? JSON.parse(local) : [];
}

export async function fetchProjectDetails(id: string): Promise<ProjectData | null> {
  try {
    const res = await fetch(`${BASE_URL}/projects/${id}`);
    if (res.ok) {
      const data = await res.json();
      localStorage.setItem(`scenecraft_prj_${id}`, JSON.stringify(data));
      return data;
    }
  } catch (e) {
    console.warn('API fetchProjectDetails fallback:', e);
  }
  const local = localStorage.getItem(`scenecraft_prj_${id}`);
  return local ? JSON.parse(local) : null;
}

export async function createProject(titolo: string, tipo: string): Promise<ProjectData> {
  try {
    const res = await fetch(`${BASE_URL}/projects`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ titolo, tipo }),
    });
    if (res.ok) {
      return await res.json();
    }
  } catch (e) {
    console.warn('API createProject fallback:', e);
  }

  const newPrj: ProjectData = {
    id: 'prj_' + Date.now(),
    titolo,
    tipo: tipo as any,
    updatedAt: new Date().toISOString(),
    scriptText: '',
    scriptTags: [],
    casting: [],
    shotList: [],
    costumi: [],
    scenografia: [],
    troupe: [],
    attrezzaturaVideo: [],
    attrezzaturaAudio: [],
    location: [],
    budget: [],
    linkedBudgetEntries: [],
  };
  localStorage.setItem(`scenecraft_prj_${newPrj.id}`, JSON.stringify(newPrj));
  return newPrj;
}

export async function updateProject(id: string, data: Partial<ProjectData>): Promise<ProjectData> {
  try {
    const res = await fetch(`${BASE_URL}/projects/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (res.ok) {
      const updated = await res.json();
      localStorage.setItem(`scenecraft_prj_${id}`, JSON.stringify(updated));
      return updated;
    }
  } catch (e) {
    console.warn('API updateProject fallback:', e);
  }

  const currentLocal = localStorage.getItem(`scenecraft_prj_${id}`);
  const current: ProjectData = currentLocal ? JSON.parse(currentLocal) : ({} as any);
  const updated = { ...current, ...data, updatedAt: new Date().toISOString() };
  localStorage.setItem(`scenecraft_prj_${id}`, JSON.stringify(updated));
  return updated;
}

export async function deleteProject(id: string): Promise<boolean> {
  try {
    const res = await fetch(`${BASE_URL}/projects/${id}`, { method: 'DELETE' });
    if (res.ok) return true;
  } catch (e) {
    console.warn('API deleteProject fallback:', e);
  }
  localStorage.removeItem(`scenecraft_prj_${id}`);
  return true;
}

// Calendar API
export async function fetchCalendarEvents(): Promise<CalendarEvent[]> {
  try {
    const res = await fetch(`${BASE_URL}/calendar`);
    if (res.ok) return await res.json();
  } catch (e) {
    console.warn('API fetchCalendar fallback:', e);
  }
  const local = localStorage.getItem('scenecraft_calendar');
  return local ? JSON.parse(local) : [];
}

export async function createCalendarEvent(eventData: Omit<CalendarEvent, 'id'>): Promise<CalendarEvent> {
  try {
    const res = await fetch(`${BASE_URL}/calendar`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(eventData),
    });
    if (res.ok) return await res.json();
  } catch (e) {
    console.warn('API createCalendar fallback:', e);
  }

  const newEv: CalendarEvent = { ...eventData, id: 'cal_' + Date.now() };
  return newEv;
}

export async function updateCalendarEvent(id: string, eventData: Partial<CalendarEvent>): Promise<CalendarEvent> {
  try {
    const res = await fetch(`${BASE_URL}/calendar/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(eventData),
    });
    if (res.ok) return await res.json();
  } catch (e) {
    console.warn('API updateCalendar fallback:', e);
  }
  return { id, ...eventData } as any;
}

export async function deleteCalendarEvent(id: string): Promise<boolean> {
  try {
    const res = await fetch(`${BASE_URL}/calendar/${id}`, { method: 'DELETE' });
    if (res.ok) return true;
  } catch (e) {
    console.warn('API deleteCalendar fallback:', e);
  }
  return true;
}

// Custom Troupe Roles
export async function fetchCustomRoles(): Promise<CustomRole[]> {
  try {
    const res = await fetch(`${BASE_URL}/user/custom-roles`);
    if (res.ok) return await res.json();
  } catch (e) {
    console.warn('API fetchCustomRoles fallback:', e);
  }
  const local = localStorage.getItem('scenecraft_custom_roles');
  return local ? JSON.parse(local) : [];
}

export async function addCustomRole(reparto: string, ruolo: string): Promise<CustomRole> {
  try {
    const res = await fetch(`${BASE_URL}/user/custom-roles`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reparto, ruolo }),
    });
    if (res.ok) return await res.json();
  } catch (e) {
    console.warn('API addCustomRole fallback:', e);
  }
  return { id: 'ctr_' + Date.now(), reparto: reparto as any, ruolo };
}

// AI Assistant
export async function askAIAssistant(prompt: string, scriptContext?: string): Promise<string> {
  try {
    const res = await fetch(`${BASE_URL}/ai/assistant`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt, scriptContext }),
    });
    if (res.ok) {
      const data = await res.json();
      return data.reply;
    }
  } catch (e) {
    console.warn('API askAIAssistant fallback:', e);
  }
  return 'Analisi completata: il budget del progetto è equilibrato, procedi con i provini del cast.';
}
